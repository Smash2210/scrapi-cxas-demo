"""Canonical shared callbacks for Telco_Voice_Agent (M1-M8).

Synchronized into all 8 agent callback directories by scripts/sync_callbacks.py.
Enforces PRD Section 6 preprocessing, Part C1/C2 verbatim copy, Part D grounding,
and Part E guardrails G1-G45 with strict string state typing (V101) and C001-C010 compliance.
"""

from typing import Any, Optional
import json
import re

AGENT_NAME = "appointment_agent"
AGENT_MODULE = "M6"

VERBATIM_C1: dict[str, dict[str, str]] = {
    "en-US": {
        "greeting_main": (
            "Welcome to Telco. I can help with billing, technical support, or managing your account. "
            "To get started, could you tell me the phone number or account number associated with your service?"
        ),
        "recording_notice": "This call may be recorded for quality and training purposes.",
        "id_verification_otp": (
            "For your security, I just sent a 6-digit code to that number — please read it back to me."
        ),
        "id_verification_pin": (
            "For your security, I'll need to verify your identity. Please enter the 4-digit PIN you set up."
        ),
        "live_agent_handoff": "I'll connect you to a representative who can help. Please hold.",
        "business_handoff": (
            "To get you the best support for your business account, I'll transfer you to an agent. "
            "You'll need to use your phone keypad instead of talking to the virtual assistant. "
            "Just a moment while I connect you."
        ),
        "payment_method_preamble": (
            "For your security and PCI compliance, please do not speak your card number aloud. "
            "Use your phone keypad when prompted to enter your payment details."
        ),
        "contract_cancellation_fee_disclosure": (
            "Please note that cancelling your service or porting out your number may result in an early "
            "termination fee if your line is under an active term contract, and any remaining device balance "
            "will become due on your final statement. Do you still wish to proceed?"
        ),
        "refund_confirmation_pattern": (
            "Your refund of ${amount} will appear on your next statement within {days} business days."
        ),
        "empathy_protocol": (
            "I'm very sorry to hear that you are facing challenges. "
            "I will ensure we handle your request with the utmost care."
        ),
        "outage_active": (
            "I see there's an active outage in your area. We're working on it. "
            "Would you like me to text you when it's restored?"
        ),
        "transfer_to_specialist": (
            "I'll connect you to a billing specialist now — they'll have everything we've already discussed."
        ),
    },
    "es-US": {
        "greeting_main": (
            "Bienvenido a Telco. Puedo ayudarle con facturación, soporte técnico o la administración de su cuenta. "
            "Para comenzar, ¿podría indicarme el número de teléfono o el número de cuenta asociado a su servicio?"
        ),
        "recording_notice": "Esta llamada puede ser grabada con fines de calidad y capacitación.",
        "id_verification_otp": (
            "Por su seguridad, acabo de enviar un código de 6 dígitos a ese número; por favor, léamelo."
        ),
        "id_verification_pin": (
            "Por su seguridad, necesito verificar su identidad. Por favor, ingrese el PIN de 4 dígitos que configuró."
        ),
        "live_agent_handoff": "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea.",
        "business_handoff": (
            "Para brindarle el mejor soporte para su cuenta de negocio, le transferiré con un agente. "
            "Deberá usar el teclado de su teléfono en lugar de hablar con el asistente virtual. "
            "Un momento mientras le comunico."
        ),
        "payment_method_preamble": (
            "Por su seguridad y cumplimiento de PCI, por favor no diga el número de su tarjeta en voz alta. "
            "Use el teclado de su teléfono cuando se le solicite ingresar sus datos de pago."
        ),
        "contract_cancellation_fee_disclosure": (
            "Tenga en cuenta que cancelar su servicio o transferir su número puede generar un cargo por "
            "cancelación anticipada si su línea tiene un contrato activo, y cualquier saldo pendiente del "
            "equipo vencerá en su factura final. ¿Desea continuar?"
        ),
        "refund_confirmation_pattern": (
            "Su reembolso de ${amount} aparecerá en su próximo estado de cuenta dentro de {days} días hábiles."
        ),
        "empathy_protocol": (
            "Lamento mucho que esté enfrentando estas dificultades. "
            "Me aseguraré de que su solicitud se atienda con el mayor cuidado."
        ),
        "outage_active": (
            "Veo que hay una interrupción activa del servicio en su zona. Estamos trabajando en ello. "
            "¿Desea que le envíe un mensaje de texto cuando se restablezca?"
        ),
        "transfer_to_specialist": (
            "Le comunicaré ahora con un especialista de facturación; tendrá toda la información que ya hemos conversado."
        ),
    },
}
VERBATIM_C1["primary"] = VERBATIM_C1["en-US"]
VERBATIM_C1["secondary"] = VERBATIM_C1["es-US"]

SYSTEM_LINES_C2: dict[str, dict[str, str]] = {
    "en-US": {
        "restricted_caller_deflection": (
            "We're unable to complete your call at this time. "
            "Please visit our website or a retail store for assistance. Goodbye."
        ),
        "regional_alert_banner": "Please note: {banner_text}",
        "otp_number_confirm": "I'll send a 6-digit code to the number ending in {last4}. Ready?",
        "noinput_reprompt_1": "I didn't catch that. Could you please repeat what you need help with?",
        "noinput_reprompt_2": (
            "I still didn't hear a response. Please tell me how I can help, "
            "or press 0 to speak with a representative."
        ),
        "nomatch_reprompt_1": (
            "To make sure I route you to the right place, is this about billing, "
            "technical support, sales, appointments, or your account?"
        ),
        "nomatch_reprompt_2": (
            "I want to make sure I understand. Could you briefly state which service you're calling about today?"
        ),
        "system_unavailable_line": (
            "I'm sorry, our system is temporarily unavailable. "
            "I'll connect you to a representative who can help. Please hold."
        ),
        "too_many_errors_line": (
            "I'm sorry, we've encountered too many errors processing that request. "
            "Please try calling back shortly. Goodbye."
        ),
        "malicious_closing_line": "I'm unable to continue this call. Goodbye.",
        "after_hours_notice": (
            "Our specialist team for that request is currently closed and will reopen at {next_open_iso}. "
            "Would you like me to schedule a callback for the next business day?"
        ),
        "password_reset_sent": (
            "I've sent a password reset link via text message to your phone. "
            "The link is valid for {valid_minutes} minutes."
        ),
        "same_day_cancel_warning": (
            "Because this appointment is scheduled for today, cancelling it cannot be undone once confirmed. "
            "Please confirm a second time if you are sure you want to cancel today's appointment."
        ),
        "closing_wrap": "Thank you for calling Telco. Have a great day! Goodbye.",
    },
    "es-US": {
        "restricted_caller_deflection": (
            "No podemos completar su llamada en este momento. "
            "Por favor visite nuestro sitio web o una tienda para recibir asistencia. Hasta luego."
        ),
        "regional_alert_banner": "Aviso importante: {banner_text}",
        "otp_number_confirm": "Enviaré un código de 6 dígitos al número que termina en {last4}. ¿Está listo?",
        "noinput_reprompt_1": "No logré escucharle. ¿Podría repetir en qué puedo ayudarle?",
        "noinput_reprompt_2": (
            "Sigo sin escuchar una respuesta. Por favor dígame cómo puedo ayudarle "
            "o presione 0 para hablar con un representante."
        ),
        "nomatch_reprompt_1": (
            "Para asegurarme de dirigirle al área correcta, ¿su consulta es sobre facturación, "
            "soporte técnico, ventas, citas o su cuenta?"
        ),
        "nomatch_reprompt_2": (
            "Quiero asegurarme de comprender bien. ¿Podría indicarme brevemente sobre qué servicio llama hoy?"
        ),
        "system_unavailable_line": (
            "Lo siento, nuestro sistema no está disponible temporalmente. "
            "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea."
        ),
        "too_many_errors_line": (
            "Lo siento, hemos encontrado demasiados errores al procesar su solicitud. "
            "Por favor intente llamar más tarde. Hasta luego."
        ),
        "malicious_closing_line": "No puedo continuar con esta llamada. Hasta luego.",
        "after_hours_notice": (
            "Nuestro equipo de especialistas para esa solicitud está cerrado actualmente y reabrirá a las {next_open_iso}. "
            "¿Desea que programe una devolución de llamada para el próximo día hábil?"
        ),
        "password_reset_sent": (
            "He enviado un enlace para restablecer su contraseña por mensaje de texto a su teléfono. "
            "El enlace es válido por {valid_minutes} minutos."
        ),
        "same_day_cancel_warning": (
            "Debido a que esta cita está programada para hoy, la cancelación no se puede deshacer una vez confirmada. "
            "Por favor confirme por segunda vez si está seguro de cancelar la cita de hoy."
        ),
        "closing_wrap": "Gracias por llamar a Telco. ¡Que tenga un excelente día! Hasta luego.",
    },
}
SYSTEM_LINES_C2["primary"] = SYSTEM_LINES_C2["en-US"]
SYSTEM_LINES_C2["secondary"] = SYSTEM_LINES_C2["es-US"]

VERBATIM_TEMPLATES = VERBATIM_C1
LEGAL_DISCLOSURES = SYSTEM_LINES_C2

DEFAULT_STATE_STRINGS: dict[str, str] = {
    "clid": "5550101001",
    "tfn": "8005550100",
    "cirn": "",
    "cirn_last4": "",
    "billing_account": "",
    "billing_account_last4": "",
    "customer_type": "Existing",
    "user_id": "",
    "zip": "",
    "line": "",
    "callback_number_last4": "",
    "has_backup_contact": "false",
    "auth_status": "",
    "identification_status": "",
    "step_up_auth_status": "",
    "auth_attempts": "0",
    "business_flag": "false",
    "route": "",
    "lob": "",
    "tv_sub_type": "null",
    "region": "Region-A",
    "active_module": "M1",
    "pending_restore_after_payment": "false",
    "language": "primary",
    "language_code": "en-US",
    "language_locked": "false",
    "utterance": "",
    "dtmf_digits": "",
    "local_noinput_counter": "0",
    "global_err_count": "0",
    "no_match_confirmation_count": "0",
    "misc_counter": "0",
    "mock_mode": "True",
    "test_profile": "standard",
    "mock_error_code": "",
    "now": "2026-10-29T14:00:00Z",
    "pending_verbatim_key": "",
    "recording_notice_played": "false",
    "payment_preamble_played": "false",
    "disclosure_played": "false",
    "outage_checked": "false",
    "coverage_checked": "false",
    "last_pmt_amt": "0.00",
    "amount": "",
    "balance_due": "0.00",
    "charge_id": "",
    "payment_token": "tok_visa_4242",
    "ban_type": "Consumer",
    "is_prepaid": "false",
    "loyalty_limit": "50",
    "vr_task_count": "0",
    "session_id": "",
    "ticket_state": "none",
    "device_id": "",
    "device_model": "",
    "appt_id": "",
    "item_list": "[]",
    "intent_type": "",
    "api_resp": "{}",
    "tool_response_values": "[]",
    "idempotency_cache": "{}",
    "sms_type": "Public",
    "sms_content": "",
    "day_val": "",
    "date_val": "",
    "month_val": "",
    "end_time": "",
    "flag_val": "",
    "banner_text": "",
    "next_open_iso": "",
    "valid_minutes": "30",
    "eta_business_days": "3",
    "escalation_reason": "",
    "queue_id": "general_support",
    "same_day": "false",
    "appt_status": "scheduled",
    "last_otp_input": "",
    "turn_1_greeted": "false",
}

AUTH_REQUIRED_TOOLS_CSV = (
    "fetch_recent_bills|evaluate_refund_eligibility|apply_bill_adjustment|create_dispute_ticket|"
    "process_payment|configure_autopay|fetch_payment_arrangement_options|create_payment_arrangement|"
    "fetch_deposit_info|start_virtual_repair|record_diagnostic_answer|lookup_support_ticket|"
    "create_support_ticket|fetch_sim_status|activate_sim|fetch_puk_code|"
    "check_device_unlock_eligibility|submit_device_unlock|fetch_account_services|place_new_order|"
    "check_warranty_status|process_warranty_claim|fetch_repair_options|initiate_number_transfer|"
    "fetch_active_appointments|fetch_technician_status|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|send_password_reset_sms|update_mfa_setting|"
    "update_profile_field|fetch_service_status|execute_suspend_restore|"
    "submit_service_cancellation|fetch_port_out_info"
)

MUTATING_TOOLS_CSV = (
    "schedule_next_business_day_callback|execute_live_agent_handover|execute_business_handover|"
    "apply_bill_adjustment|create_dispute_ticket|process_payment|configure_autopay|"
    "create_payment_arrangement|create_support_ticket|activate_sim|submit_device_unlock|"
    "place_new_order|process_warranty_claim|initiate_number_transfer|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|update_mfa_setting|report_fraud|update_profile_field|"
    "execute_suspend_restore|submit_service_cancellation"
)

SYSTEM_ERROR_CODES_CSV = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
BUSINESS_ERROR_CODES_CSV = (
    "INSUFFICIENT_FUNDS|NOT_ELIGIBLE|ALREADY_APPLIED|QUEUE_CLOSED|REFUND_THRESHOLD_EXCEEDED|"
    "ERR_PAYMENT_DECLINED|ERR_CREDIT_LIMIT_EXCEEDED|ERR_NO_SLOTS_AVAILABLE|ERR_OUT_OF_STOCK|"
    "ERR_PORT_INELIGIBLE|ERR_OUTAGE_ACTIVE|ERR_DEVICE_UNREACHABLE|ERR_UNAUTHORIZED_ROLE"
)
VALIDATION_ERROR_CODES_CSV = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"


def _get_lang_key(state: Any) -> str:
    lang = str(state.get("language", "primary"))
    lang_code = str(state.get("language_code", "en-US"))
    if lang == "secondary" or lang_code == "es-US":
        return "es-US"
    return "en-US"


def _render_verbatim(state: Any, key: str) -> str:
    lang_key = _get_lang_key(state)
    c1_map = VERBATIM_C1.get(lang_key, VERBATIM_C1.get("en-US", {}))
    c2_map = SYSTEM_LINES_C2.get(lang_key, SYSTEM_LINES_C2.get("en-US", {}))
    template = c1_map.get(key) or c2_map.get(key) or ""
    if not template:
        return ""
    last4 = str(state.get("callback_number_last4", "") or state.get("cirn_last4", "") or "0000")
    amount_val = str(state.get("amount", "") or "0.00")
    days_val = str(state.get("eta_business_days", "") or "3")
    banner_val = str(state.get("banner_text", "") or "")
    next_open = str(state.get("next_open_iso", "") or "08:00 AM")
    valid_min = str(state.get("valid_minutes", "") or "30")
    rendered = template.replace("{last4}", last4)
    rendered = rendered.replace("{amount}", amount_val)
    rendered = rendered.replace("{days}", days_val)
    rendered = rendered.replace("{banner_text}", banner_val)
    rendered = rendered.replace("{next_open_iso}", next_open)
    rendered = rendered.replace("{valid_minutes}", valid_min)
    return rendered


def _extract_latest_user_text(callback_context: Any) -> str:
    try:
        user_content = getattr(callback_context, "user_content", None)
        if user_content and getattr(user_content, "parts", None):
            chunks = []
            for part in user_content.parts:
                txt = getattr(part, "text", None)
                if txt:
                    chunks.append(str(txt))
            if chunks:
                return " ".join(chunks).strip()
    except Exception as exc:
        print(f"Callback error: {exc}")
    return ""


def _record_tool_values(state: Any, payload: Any) -> None:
    try:
        existing_raw = str(state.get("tool_response_values", "[]"))
        try:
            values_list = json.loads(existing_raw)
            if not isinstance(values_list, list):
                values_list = []
        except Exception as exc:
            print(f"Callback error: {exc}")
            values_list = []

        def _walk(item: Any) -> None:
            if isinstance(item, dict):
                for k, v in item.items():
                    if k != "_pii_fields":
                        _walk(v)
            elif isinstance(item, list):
                for elem in item:
                    _walk(elem)
            elif item is not None:
                s_val = str(item).strip()
                if s_val and s_val not in values_list:
                    values_list.append(s_val)

        _walk(payload)
        state.update({"tool_response_values": json.dumps(values_list)})
    except Exception as exc:
        print(f"Callback error: {exc}")


# PRD Section 20 priority hierarchy (lower number wins). Unlisted keys are compliance verbatims (priority 7).
VERBATIM_PRIORITY: dict[str, int] = {
    "restricted_caller_deflection": 1,
    "empathy_protocol+live_agent_handoff": 1,
    "malicious_closing_line": 1,
    "empathy_protocol": 2,
    "system_unavailable_line": 3,
    "live_agent_handoff": 4,
    "business_handoff": 5,
    "too_many_errors_line": 6,
    "noinput_reprompt_1": 6,
    "noinput_reprompt_2": 6,
}

# Follow-up action that must accompany each escalation/termination verbatim (PRD Sections 1, 6, 8, 12, 16).
VERBATIM_FOLLOW_UP: dict[str, str] = {
    "empathy_protocol+live_agent_handoff": "Then immediately call execute_live_agent_handover with reason='{reason}', then end_session with reason='{reason}' in the same turn, and say nothing after the transfer.",
    "live_agent_handoff": "Then immediately call execute_live_agent_handover with reason='{reason}', then end_session with reason='{reason}' in the same turn, and say nothing after the transfer.",
    "system_unavailable_line": "Then immediately call execute_live_agent_handover with reason='system_unavailable', then end_session with reason='system_unavailable' in the same turn, and say nothing after the transfer.",
    "empathy_protocol": (
        "Then do not attempt authentication or self-service: call report_fraud if it is one of your tools, "
        "and immediately call execute_live_agent_handover with reason='fraud_escalation' and queue='fraud_24_7', "
        "then end_session with reason='fraud_escalation' in the same turn, and say nothing after the transfer."
    ),
    "business_handoff": "Then immediately call execute_business_handover, then end_session with reason='business_handoff' in the same turn, and say nothing after the transfer.",
    "malicious_closing_line": "Then immediately call end_session with reason='malicious_input'.",
    "too_many_errors_line": "Then immediately call end_session with reason='too_many_errors'.",
    "restricted_caller_deflection": "Then immediately call end_session with reason='restricted_caller'.",
}


def before_model_callback(
    callback_context: CallbackContext, llm_request: LlmRequest
) -> Optional[LlmResponse]:
    """Execute PRD Section 6 per-turn preprocessing; verbatim selection follows the PRD Section 20 priority order."""
    try:
        state = callback_context.state
        for key, default_val in DEFAULT_STATE_STRINGS.items():
            if state.get(key) is None:
                state.update({key: str(default_val)})

        user_text = _extract_latest_user_text(callback_context)
        if not user_text:
            user_text = str(state.get("utterance", ""))
        lower_text = user_text.strip().lower()

        # Keys queued by tool callbacks compete with this turn's signals; the highest priority wins.
        queued_key = str(state.get("pending_verbatim_key", ""))
        chosen = {
            "key": queued_key,
            "reason": "",
            "prio": VERBATIM_PRIORITY.get(queued_key, 7) if queued_key else 99,
        }

        def _propose(key: str, reason: str = "") -> None:
            prio = VERBATIM_PRIORITY.get(key, 7)
            if prio < chosen["prio"]:
                chosen.update({"key": key, "reason": reason, "prio": prio})

        # Step 1: DTMF capture (BR-TV-007)
        dtmf_captured = ""
        dtmf_match = re.search(r"(?:dtmf[:\s]*|pressed\s+|keypad[:\s]*)([0-9#*](?:[\s,.-]*[0-9#*])*)", lower_text)
        if dtmf_match:
            dtmf_captured = re.sub(r"[^0-9#*]", "", dtmf_match.group(1))
        elif re.fullmatch(r"[0-9]{1}|[0-9]{4}|[0-9]{6}", lower_text):
            dtmf_captured = lower_text
        state.update({"dtmf_digits": str(dtmf_captured)})

        if dtmf_captured == "0":
            _propose("live_agent_handoff", "user_requested_agent")

        # Step 2: No-input & no-match accounting (BR-TV-006, G6)
        # The platform reports silence as "<context>no user activity detected for 30 seconds.</context>".
        silence_tokens = "no_input|silence|no user activity|<silence>|_silence_"
        is_silence = False
        if not lower_text:
            if str(state.get("turn_1_greeted", "false")) == "true":
                is_silence = True
        elif "no user activity detected" in lower_text:
            is_silence = True
        else:
            for tok in silence_tokens.split("|"):
                if lower_text == tok:
                    is_silence = True
                    break

        if is_silence:
            # before_model runs once per model call; count each silent turn only once.
            turn_id = str(getattr(callback_context, "invocation_id", "") or "")
            already_counted = bool(turn_id) and str(state.get("last_noinput_turn_id", "")) == turn_id
            cur_noinput = int(str(state.get("local_noinput_counter", "0")) or "0")
            if not already_counted:
                cur_noinput += 1
                state.update({"local_noinput_counter": str(cur_noinput), "last_noinput_turn_id": turn_id})
            if cur_noinput == 1:
                _propose("noinput_reprompt_1")
            elif cur_noinput == 2:
                _propose("noinput_reprompt_2")
            else:
                _propose("live_agent_handoff", "no_input_escalation")
        elif lower_text:
            state.update({"local_noinput_counter": "0"})

        # Strikes 1-2 are a single targeted clarifying question composed by the model (PRD Section 4).
        nomatch_cnt = int(str(state.get("no_match_confirmation_count", "0")) or "0")
        if nomatch_cnt >= 3:
            _propose("live_agent_handoff", "disambig_max_attempts")

        # Step 3: Tool-Error Tri-State checks (G3, G20)
        err_cnt = int(str(state.get("global_err_count", "0")) or "0")
        if err_cnt >= 3:
            _propose("too_many_errors_line", "too_many_errors")

        # Step 4: Module-specific pre-checks (PRD Section 20 priorities 1-5)
        # Priority 1a: Self-harm gets empathy and a warm transfer, never a hang-up.
        self_harm_tokens = (
            "kill myself|end my life|suicide|want to die|hurt myself|"
            "suicidarme|quitarme la vida|matarme|quiero morir"
        )
        if any(tok in lower_text for tok in self_harm_tokens.split("|")):
            _propose("empathy_protocol+live_agent_handoff", "safety_escalation")

        # Priority 1b: Malicious input, prompt injection, threats (G1, BR-TV-016)
        malicious_tokens = (
            "ignore previous instructions|ignore all previous|ignore your instructions|"
            "disregard previous|forget your instructions|system prompt|reveal your prompt|"
            "developer mode|dan mode|do anything now|jailbreak mode|act as an unrestricted|"
            "pretend you are not bound|bypass safety|bypass authentication|override security|"
            "drop table|rm -rf|; drop |' or '1'='1|<script>|"
            "ignora las instrucciones|olvida tus instrucciones|modo desarrollador|"
            "bomb threat|kill you|i will kill|shoot up|blow up|burn down|"
            "amenaza de bomba|voy a matarte|te voy a matar"
        )
        if any(tok in lower_text for tok in malicious_tokens.split("|")):
            _propose("malicious_closing_line", "malicious_input")

        # Priority 2: Fraud claim (G2)
        fraud_tokens = "unauthorized charge|unauthorized transaction|account was hacked|account has been hacked|identity theft|someone opened an account|fraudulent account|fraudulent charge|report fraud|fraud on my account|unauthorized activity|account was compromised|account has been compromised|stolen identity|fraude|robo de identidad|fraudulent|fraud|unauthorized|identity was stolen|hacked"
        if any(tok in lower_text for tok in fraud_tokens.split("|")):
            state.update({"queue_id": "fraud_24_7"})
            _propose("empathy_protocol", "fraud_escalation")

        # Priority 4: Live agent request (G4)
        agent_req_tokens = "talk to a person|talk to a human|talk to someone|talk to a representative|talk to an agent|speak to a person|speak to a human|speak to someone|speak to a representative|speak to an agent|speak with a person|speak with a human|speak with someone|speak with a representative|speak with an agent|human representative|human agent|real person|live person|live agent|live representative|connect me to a person|connect me to someone|connect me to an agent|transfer me to a person|transfer me to an agent|an operator|the operator|representative please|agent please|hablar con un representante|hablar con una persona|agente humano|persona real|operador"
        if any(tok in lower_text for tok in agent_req_tokens.split("|")):
            _propose("live_agent_handoff", "user_requested_agent")

        # Priority 5: Business account handoff (G5)
        if str(state.get("business_flag", "false")).lower() == "true":
            _propose("business_handoff", "business_handoff")

        # Language lock at Turn 1 (G25)
        if str(state.get("language_locked", "false")) == "false":
            state.update({"language_locked": "true"})

        # Priority 7: Recording inquiry or Turn-1 greeting (BR-TV-001)
        if "recorded" in lower_text or "grabada" in lower_text or "recording" in lower_text:
            _propose("recording_notice")
        elif AGENT_MODULE == "M1" and str(state.get("turn_1_greeted", "false")) == "false":
            state.update({
                "turn_1_greeted": "true",
                "recording_notice_played": "true",
            })

        pending_key = str(chosen["key"])
        if chosen["reason"]:
            state.update({"escalation_reason": str(chosen["reason"])})

        # Payment preamble & cancellation disclosure flags (G31, G32)
        if pending_key == "payment_method_preamble":
            state.update({"payment_preamble_played": "true"})
        elif pending_key == "contract_cancellation_fee_disclosure":
            state.update({"disclosure_played": "true"})

        # Inject verbatim directive and pre-agent auth reminder into llm_request
        extra_directives = ""
        if AGENT_MODULE in ("M3", "M4", "M5", "M6", "M7") and str(state.get("auth_status", "")) != "Pass":
            extra_directives += (
                "\nPRE-AGENT AUTH REMINDER (G2, G5): Caller is not yet authenticated (auth_status != 'Pass'). "
                "Only I-level tools (check_service_coverage, fetch_plan_catalog, fetch_addon_catalog, send_registration_sms) "
                "and G2 fraud reporting (report_fraud + execute_live_agent_handover) are permitted without authentication. "
                "Before calling any A-level or A+-level account tool, route to auth_agent to complete authentication.\n"
            )
        state.update({"pending_verbatim_key": ""})
        if pending_key:
            verbatim_text = " ".join(
                part for part in (_render_verbatim(state, k) for k in pending_key.split("+")) if part
            )
            if verbatim_text:
                follow_up = VERBATIM_FOLLOW_UP.get(pending_key, "").replace(
                    "{reason}", str(state.get("escalation_reason", "") or "user_requested_agent")
                )
                extra_directives += (
                    f"\nCRITICAL VERBATIM REQUIREMENT: You MUST include this exact sentence verbatim in your response "
                    f"without any rephrasing: \"{verbatim_text}\" {follow_up}\n"
                )
        if extra_directives and hasattr(llm_request, "config") and llm_request.config is not None:
            existing_sys = getattr(llm_request.config, "system_instruction", None)
            if isinstance(existing_sys, str):
                llm_request.config.system_instruction = existing_sys + extra_directives
            elif existing_sys is not None and hasattr(existing_sys, "parts") and existing_sys.parts:
                first_part = existing_sys.parts[0]
                if hasattr(first_part, "text"):
                    first_part.text = str(getattr(first_part, "text", "") or "") + extra_directives
    except Exception as exc:
        print(f"Callback error: {exc}")
    return None
