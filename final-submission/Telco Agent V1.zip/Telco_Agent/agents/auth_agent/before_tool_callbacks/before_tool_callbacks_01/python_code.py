"""Canonical shared callbacks for Telco_Voice_Agent (M1-M8).

Synchronized into all 8 agent callback directories by scripts/sync_callbacks.py.
Enforces PRD Section 6 preprocessing, Part C1/C2 verbatim copy, Part D grounding,
and Part E guardrails G1-G45 with strict string state typing (V101) and C001-C010 compliance.
"""

from typing import Any, Optional
import json
import re

AGENT_NAME = "auth_agent"
AGENT_MODULE = "M2"

VERBATIM_C1: dict[str, dict[str, str]] = {
    "en-US": {
        "greeting_main": (
            "Welcome to Telco. I can help with billing, technical support, or managing your account. "
            "To get started, could you tell me the phone number or account number associated with your service?"
        ),
        "recording_notice": "This call may be recorded for quality and training purposes.",
        "id_verification_otp": (
            "For your security, I just sent a 6-digit code to that number — please read it back to me."
        ),
        "id_verification_pin": (
            "For your security, I'll need to verify your identity. Please enter the 4-digit PIN you set up."
        ),
        "live_agent_handoff": "I'll connect you to a representative who can help. Please hold.",
        "business_handoff": (
            "To get you the best support for your business account, I'll transfer you to an agent. "
            "You'll need to use your phone keypad instead of talking to the virtual assistant. "
            "Just a moment while I connect you."
        ),
        "payment_method_preamble": (
            "For your security and PCI compliance, please do not speak your card number aloud. "
            "Use your phone keypad when prompted to enter your payment details."
        ),
        "contract_cancellation_fee_disclosure": (
            "Please note that cancelling your service or porting out your number may result in an early "
            "termination fee if your line is under an active term contract, and any remaining device balance "
            "will become due on your final statement. Do you still wish to proceed?"
        ),
        "refund_confirmation_pattern": (
            "Your refund of ${amount} will appear on your next statement within {days} business days."
        ),
        "empathy_protocol": (
            "I'm very sorry to hear that you are facing challenges. "
            "I will ensure we handle your request with the utmost care."
        ),
        "outage_active": (
            "I see there's an active outage in your area. We're working on it. "
            "Would you like me to text you when it's restored?"
        ),
        "transfer_to_specialist": (
            "I'll connect you to a billing specialist now — they'll have everything we've already discussed."
        ),
    },
    "es-US": {
        "greeting_main": (
            "Bienvenido a Telco. Puedo ayudarle con facturación, soporte técnico o la administración de su cuenta. "
            "Para comenzar, ¿podría indicarme el número de teléfono o el número de cuenta asociado a su servicio?"
        ),
        "recording_notice": "Esta llamada puede ser grabada con fines de calidad y capacitación.",
        "id_verification_otp": (
            "Por su seguridad, acabo de enviar un código de 6 dígitos a ese número; por favor, léamelo."
        ),
        "id_verification_pin": (
            "Por su seguridad, necesito verificar su identidad. Por favor, ingrese el PIN de 4 dígitos que configuró."
        ),
        "live_agent_handoff": "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea.",
        "business_handoff": (
            "Para brindarle el mejor soporte para su cuenta de negocio, le transferiré con un agente. "
            "Deberá usar el teclado de su teléfono en lugar de hablar con el asistente virtual. "
            "Un momento mientras le comunico."
        ),
        "payment_method_preamble": (
            "Por su seguridad y cumplimiento de PCI, por favor no diga el número de su tarjeta en voz alta. "
            "Use el teclado de su teléfono cuando se le solicite ingresar sus datos de pago."
        ),
        "contract_cancellation_fee_disclosure": (
            "Tenga en cuenta que cancelar su servicio o transferir su número puede generar un cargo por "
            "cancelación anticipada si su línea tiene un contrato activo, y cualquier saldo pendiente del "
            "equipo vencerá en su factura final. ¿Desea continuar?"
        ),
        "refund_confirmation_pattern": (
            "Su reembolso de ${amount} aparecerá en su próximo estado de cuenta dentro de {days} días hábiles."
        ),
        "empathy_protocol": (
            "Lamento mucho que esté enfrentando estas dificultades. "
            "Me aseguraré de que su solicitud se atienda con el mayor cuidado."
        ),
        "outage_active": (
            "Veo que hay una interrupción activa del servicio en su zona. Estamos trabajando en ello. "
            "¿Desea que le envíe un mensaje de texto cuando se restablezca?"
        ),
        "transfer_to_specialist": (
            "Le comunicaré ahora con un especialista de facturación; tendrá toda la información que ya hemos conversado."
        ),
    },
}
VERBATIM_C1["primary"] = VERBATIM_C1["en-US"]
VERBATIM_C1["secondary"] = VERBATIM_C1["es-US"]

SYSTEM_LINES_C2: dict[str, dict[str, str]] = {
    "en-US": {
        "restricted_caller_deflection": (
            "We're unable to complete your call at this time. "
            "Please visit our website or a retail store for assistance. Goodbye."
        ),
        "regional_alert_banner": "Please note: {banner_text}",
        "otp_number_confirm": "I'll send a 6-digit code to the number ending in {last4}. Ready?",
        "noinput_reprompt_1": "I didn't catch that. Could you please repeat what you need help with?",
        "noinput_reprompt_2": (
            "I still didn't hear a response. Please tell me how I can help, "
            "or press 0 to speak with a representative."
        ),
        "nomatch_reprompt_1": (
            "To make sure I route you to the right place, is this about billing, "
            "technical support, sales, appointments, or your account?"
        ),
        "nomatch_reprompt_2": (
            "I want to make sure I understand. Could you briefly state which service you're calling about today?"
        ),
        "system_unavailable_line": (
            "I'm sorry, our system is temporarily unavailable. "
            "I'll connect you to a representative who can help. Please hold."
        ),
        "too_many_errors_line": (
            "I'm sorry, we've encountered too many errors processing that request. "
            "Please try calling back shortly. Goodbye."
        ),
        "malicious_closing_line": "I'm unable to continue this call. Goodbye.",
        "after_hours_notice": (
            "Our specialist team for that request is currently closed and will reopen at {next_open_iso}. "
            "Would you like me to schedule a callback for the next business day?"
        ),
        "password_reset_sent": (
            "I've sent a password reset link via text message to your phone. "
            "The link is valid for {valid_minutes} minutes."
        ),
        "same_day_cancel_warning": (
            "Because this appointment is scheduled for today, cancelling it cannot be undone once confirmed. "
            "Please confirm a second time if you are sure you want to cancel today's appointment."
        ),
        "closing_wrap": "Thank you for calling Telco. Have a great day! Goodbye.",
    },
    "es-US": {
        "restricted_caller_deflection": (
            "No podemos completar su llamada en este momento. "
            "Por favor visite nuestro sitio web o una tienda para recibir asistencia. Hasta luego."
        ),
        "regional_alert_banner": "Aviso importante: {banner_text}",
        "otp_number_confirm": "Enviaré un código de 6 dígitos al número que termina en {last4}. ¿Está listo?",
        "noinput_reprompt_1": "No logré escucharle. ¿Podría repetir en qué puedo ayudarle?",
        "noinput_reprompt_2": (
            "Sigo sin escuchar una respuesta. Por favor dígame cómo puedo ayudarle "
            "o presione 0 para hablar con un representante."
        ),
        "nomatch_reprompt_1": (
            "Para asegurarme de dirigirle al área correcta, ¿su consulta es sobre facturación, "
            "soporte técnico, ventas, citas o su cuenta?"
        ),
        "nomatch_reprompt_2": (
            "Quiero asegurarme de comprender bien. ¿Podría indicarme brevemente sobre qué servicio llama hoy?"
        ),
        "system_unavailable_line": (
            "Lo siento, nuestro sistema no está disponible temporalmente. "
            "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea."
        ),
        "too_many_errors_line": (
            "Lo siento, hemos encontrado demasiados errores al procesar su solicitud. "
            "Por favor intente llamar más tarde. Hasta luego."
        ),
        "malicious_closing_line": "No puedo continuar con esta llamada. Hasta luego.",
        "after_hours_notice": (
            "Nuestro equipo de especialistas para esa solicitud está cerrado actualmente y reabrirá a las {next_open_iso}. "
            "¿Desea que programe una devolución de llamada para el próximo día hábil?"
        ),
        "password_reset_sent": (
            "He enviado un enlace para restablecer su contraseña por mensaje de texto a su teléfono. "
            "El enlace es válido por {valid_minutes} minutos."
        ),
        "same_day_cancel_warning": (
            "Debido a que esta cita está programada para hoy, la cancelación no se puede deshacer una vez confirmada. "
            "Por favor confirme por segunda vez si está seguro de cancelar la cita de hoy."
        ),
        "closing_wrap": "Gracias por llamar a Telco. ¡Que tenga un excelente día! Hasta luego.",
    },
}
SYSTEM_LINES_C2["primary"] = SYSTEM_LINES_C2["en-US"]
SYSTEM_LINES_C2["secondary"] = SYSTEM_LINES_C2["es-US"]

VERBATIM_TEMPLATES = VERBATIM_C1
LEGAL_DISCLOSURES = SYSTEM_LINES_C2

DEFAULT_STATE_STRINGS: dict[str, str] = {
    "clid": "5550101001",
    "tfn": "8005550100",
    "cirn": "",
    "cirn_last4": "",
    "billing_account": "",
    "billing_account_last4": "",
    "customer_type": "Existing",
    "user_id": "",
    "zip": "",
    "line": "",
    "callback_number_last4": "",
    "has_backup_contact": "false",
    "auth_status": "",
    "identification_status": "",
    "step_up_auth_status": "",
    "auth_attempts": "0",
    "business_flag": "false",
    "route": "",
    "lob": "",
    "tv_sub_type": "null",
    "region": "Region-A",
    "active_module": "M1",
    "pending_restore_after_payment": "false",
    "language": "primary",
    "language_code": "en-US",
    "language_locked": "false",
    "utterance": "",
    "dtmf_digits": "",
    "local_noinput_counter": "0",
    "global_err_count": "0",
    "no_match_confirmation_count": "0",
    "misc_counter": "0",
    "mock_mode": "True",
    "test_profile": "standard",
    "mock_error_code": "",
    "now": "2026-10-29T14:00:00Z",
    "pending_verbatim_key": "",
    "recording_notice_played": "false",
    "payment_preamble_played": "false",
    "disclosure_played": "false",
    "outage_checked": "false",
    "coverage_checked": "false",
    "last_pmt_amt": "0.00",
    "amount": "",
    "balance_due": "0.00",
    "charge_id": "",
    "payment_token": "tok_visa_4242",
    "ban_type": "Consumer",
    "is_prepaid": "false",
    "loyalty_limit": "50",
    "vr_task_count": "0",
    "session_id": "",
    "ticket_state": "none",
    "device_id": "",
    "device_model": "",
    "appt_id": "",
    "item_list": "[]",
    "intent_type": "",
    "api_resp": "{}",
    "tool_response_values": "[]",
    "idempotency_cache": "{}",
    "sms_type": "Public",
    "sms_content": "",
    "day_val": "",
    "date_val": "",
    "month_val": "",
    "end_time": "",
    "flag_val": "",
    "banner_text": "",
    "next_open_iso": "",
    "valid_minutes": "30",
    "eta_business_days": "3",
    "escalation_reason": "",
    "queue_id": "general_support",
    "same_day": "false",
    "appt_status": "scheduled",
    "last_otp_input": "",
    "turn_1_greeted": "false",
}

AUTH_REQUIRED_TOOLS_CSV = (
    "fetch_recent_bills|evaluate_refund_eligibility|apply_bill_adjustment|create_dispute_ticket|"
    "process_payment|configure_autopay|fetch_payment_arrangement_options|create_payment_arrangement|"
    "fetch_deposit_info|start_virtual_repair|record_diagnostic_answer|lookup_support_ticket|"
    "create_support_ticket|fetch_sim_status|activate_sim|fetch_puk_code|"
    "check_device_unlock_eligibility|submit_device_unlock|fetch_account_services|place_new_order|"
    "check_warranty_status|process_warranty_claim|fetch_repair_options|initiate_number_transfer|"
    "fetch_active_appointments|fetch_technician_status|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|send_password_reset_sms|update_mfa_setting|"
    "update_profile_field|fetch_service_status|execute_suspend_restore|"
    "submit_service_cancellation|fetch_port_out_info"
)

MUTATING_TOOLS_CSV = (
    "schedule_next_business_day_callback|execute_live_agent_handover|execute_business_handover|"
    "apply_bill_adjustment|create_dispute_ticket|process_payment|configure_autopay|"
    "create_payment_arrangement|create_support_ticket|activate_sim|submit_device_unlock|"
    "place_new_order|process_warranty_claim|initiate_number_transfer|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|update_mfa_setting|report_fraud|update_profile_field|"
    "execute_suspend_restore|submit_service_cancellation"
)

SYSTEM_ERROR_CODES_CSV = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
BUSINESS_ERROR_CODES_CSV = (
    "INSUFFICIENT_FUNDS|NOT_ELIGIBLE|ALREADY_APPLIED|QUEUE_CLOSED|REFUND_THRESHOLD_EXCEEDED|"
    "ERR_PAYMENT_DECLINED|ERR_CREDIT_LIMIT_EXCEEDED|ERR_NO_SLOTS_AVAILABLE|ERR_OUT_OF_STOCK|"
    "ERR_PORT_INELIGIBLE|ERR_OUTAGE_ACTIVE|ERR_DEVICE_UNREACHABLE|ERR_UNAUTHORIZED_ROLE"
)
VALIDATION_ERROR_CODES_CSV = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"


def _get_lang_key(state: Any) -> str:
    lang = str(state.get("language", "primary"))
    lang_code = str(state.get("language_code", "en-US"))
    if lang == "secondary" or lang_code == "es-US":
        return "es-US"
    return "en-US"


def _render_verbatim(state: Any, key: str) -> str:
    lang_key = _get_lang_key(state)
    c1_map = VERBATIM_C1.get(lang_key, VERBATIM_C1.get("en-US", {}))
    c2_map = SYSTEM_LINES_C2.get(lang_key, SYSTEM_LINES_C2.get("en-US", {}))
    template = c1_map.get(key) or c2_map.get(key) or ""
    if not template:
        return ""
    last4 = str(state.get("callback_number_last4", "") or state.get("cirn_last4", "") or "0000")
    amount_val = str(state.get("amount", "") or "0.00")
    days_val = str(state.get("eta_business_days", "") or "3")
    banner_val = str(state.get("banner_text", "") or "")
    next_open = str(state.get("next_open_iso", "") or "08:00 AM")
    valid_min = str(state.get("valid_minutes", "") or "30")
    rendered = template.replace("{last4}", last4)
    rendered = rendered.replace("{amount}", amount_val)
    rendered = rendered.replace("{days}", days_val)
    rendered = rendered.replace("{banner_text}", banner_val)
    rendered = rendered.replace("{next_open_iso}", next_open)
    rendered = rendered.replace("{valid_minutes}", valid_min)
    return rendered


def _extract_latest_user_text(callback_context: Any) -> str:
    try:
        user_content = getattr(callback_context, "user_content", None)
        if user_content and getattr(user_content, "parts", None):
            chunks = []
            for part in user_content.parts:
                txt = getattr(part, "text", None)
                if txt:
                    chunks.append(str(txt))
            if chunks:
                return " ".join(chunks).strip()
    except Exception as exc:
        print(f"Callback error: {exc}")
    return ""


def _record_tool_values(state: Any, payload: Any) -> None:
    try:
        existing_raw = str(state.get("tool_response_values", "[]"))
        try:
            values_list = json.loads(existing_raw)
            if not isinstance(values_list, list):
                values_list = []
        except Exception as exc:
            print(f"Callback error: {exc}")
            values_list = []

        def _walk(item: Any) -> None:
            if isinstance(item, dict):
                for k, v in item.items():
                    if k != "_pii_fields":
                        _walk(v)
            elif isinstance(item, list):
                for elem in item:
                    _walk(elem)
            elif item is not None:
                s_val = str(item).strip()
                if s_val and s_val not in values_list:
                    values_list.append(s_val)

        _walk(payload)
        state.update({"tool_response_values": json.dumps(values_list)})
    except Exception as exc:
        print(f"Callback error: {exc}")


def before_tool_callback(
    tool: Tool, input: dict[str, Any], callback_context: CallbackContext
) -> Optional[dict[str, Any]]:
    """Enforce deterministic tool preconditions (G8-G12, G27, G29, G31, G32, G34, G35, G38, G41, G42)."""
    try:
        state = callback_context.state
        tool_name = str(getattr(tool, "name", "") or "")

        # G41: Populate missing arguments from session state
        if isinstance(input, dict):
            state_fallback_keys = "clid|cirn|billing_account|region|zip|line|lob|tv_sub_type|session_id|appt_id|device_id|charge_id|payment_token|dtmf_digits"
            for k in state_fallback_keys.split("|"):
                if k in input and (input.get(k) is None or str(input.get(k)).strip() == ""):
                    state_val = str(state.get(k, "")).strip()
                    if state_val and state_val != "null":
                        input[k] = state_val
            if "zip_code" in input and not str(input.get("zip_code", "")).strip():
                z_val = str(state.get("zip", "")).strip()
                if z_val:
                    input["zip_code"] = z_val
            if "vr_session_id" in input and not str(input.get("vr_session_id", "")).strip():
                s_val = str(state.get("session_id", "")).strip()
                if s_val:
                    input["vr_session_id"] = s_val

        # G10: Protect auth_status, identification_status, step_up_auth_status in set_session_state
        if tool_name == "set_session_state":
            target_key = str(input.get("key", "")).strip()
            target_val = str(input.get("value", "")).strip()
            protected_keys = "auth_status|identification_status|step_up_auth_status"
            for pk in protected_keys.split("|"):
                if target_key == pk:
                    if str(state.get(target_key, "")).strip() == target_val and target_val == "Pass":
                        return {
                            "status": "success",
                            "key": target_key,
                            "value": target_val,
                            "updated": "true",
                        }
                    return {
                        "status": "error",
                        "error_code": "INVALID_INPUT",
                        "error": "INVALID_INPUT",
                        "message": f"Key '{target_key}' is write-protected by G10.",
                        "agent_action": "Use authentication tools (#3, #13, #14) to update auth state.",
                    }
            # Tool-sourced values (money, flags, counters, test harness) are never model-writable.
            tool_owned_keys = "balance_due|last_pmt_amt|business_flag|payment_token|is_prepaid|loyalty_limit|ban_type|customer_type|user_id|region|cirn_last4|billing_account_last4|callback_number_last4|has_backup_contact|mock_mode|mock_error_code|test_profile|now|idempotency_cache|tool_response_values|api_resp|global_err_count|local_noinput_counter|no_match_confirmation_count|auth_attempts|misc_counter|vr_task_count|outage_checked|coverage_checked|appt_status|same_day|ticket_state|session_id|banner_text|next_open_iso|valid_minutes|eta_business_days|language_locked|turn_1_greeted|recording_notice_played|pending_verbatim_key"
            if target_key in tool_owned_keys.split("|"):
                return {
                    "status": "error",
                    "error_code": "INVALID_INPUT",
                    "error": "INVALID_INPUT",
                    "message": f"Key '{target_key}' is set only by backend tools and cannot be changed here.",
                    "agent_action": "Do not modify this value; use the appropriate backend tool instead.",
                }
            if target_key == "payment_preamble_played" and target_val.lower() == "true":
                if str(state.get("payment_preamble_played", "false")) != "true":
                    state.update({"pending_verbatim_key": "payment_method_preamble"})
                state.update({"payment_preamble_played": "true"})
            elif target_key == "disclosure_played" and target_val.lower() == "true":
                if str(state.get("disclosure_played", "false")) != "true":
                    state.update({"pending_verbatim_key": "contract_cancellation_fee_disclosure"})
                state.update({"disclosure_played": "true"})

        # Escalation guard: live-agent transfers only for PRD escalation conditions (Sections 1, 6, 16, 20).
        if tool_name == "execute_live_agent_handover":
            allowed_reasons = (
                "user_requested_agent|fraud_escalation|auth_failure_handoff|no_input_escalation|disambig_max_attempts|"
                "refund_threshold_exceeded|system_unavailable|too_many_errors|safety_escalation|"
                "secondary_language_live_agent|business_handoff"
            )
            person_words = (
                "person|human|agent|representative|someone|operator|supervisor|manager|specialist|"
                "persona|representante|agente|operador"
            )
            state_reason = str(state.get("escalation_reason", "")).strip()
            utterance = str(state.get("utterance", "")).lower()
            attempts = int(str(state.get("auth_attempts", "0")) or "0")
            justified = (
                state_reason in allowed_reasons.split("|")
                or any(w in utterance for w in person_words.split("|"))
                or attempts >= 3
                or str(state.get("queue_id", "")) == "fraud_24_7"
                or AGENT_MODULE == "M8"
            )
            if not justified:
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "No escalation condition is met, so a live-agent transfer is not allowed.",
                    "agent_action": (
                        "Do not transfer and do not mention a transfer. Keep helping the caller with your own tools; "
                        "if their request belongs to another Telco team, hand control back to telco_root_agent so it "
                        "can route them."
                    ),
                }

        # G8: Auth Gate on A-level tools
        auth_tools = AUTH_REQUIRED_TOOLS_CSV.split("|")
        if tool_name in auth_tools:
            if str(state.get("auth_status", "")) != "Pass":
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Caller must be authenticated (auth_status == 'Pass') before invoking this tool.",
                    "agent_action": (
                        "Verify the caller yourself now, without transferring: confirm the callback number ending in "
                        f"{state.get('callback_number_last4', '') or 'the number on file'}, call send_authentication_otp, ask for the "
                        "6-digit code, and call validate_authentication_otp. Then retry this request."
                    ),
                }

        # G9: Step-up Auth Gate on #52 update_mfa_setting
        if tool_name == "update_mfa_setting":
            if str(state.get("step_up_auth_status", "")) != "Pass":
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Step-up authentication (step_up_auth_status == 'Pass') is required for MFA updates.",
                    "agent_action": "Complete step-up authentication with purpose='step_up' before calling update_mfa_setting.",
                }

        # G12: DTMF-only PIN Gate on #14 validate_authentication_pin
        if tool_name == "validate_authentication_pin":
            digits = str(input.get("dtmf_digits", "") or state.get("dtmf_digits", "")).strip()
            if not digits:
                return {
                    "status": "error",
                    "error_code": "INVALID_INPUT",
                    "error": "INVALID_INPUT",
                    "message": "PIN must be entered via phone keypad (DTMF); spoken PINs cannot be accepted.",
                    "agent_action": "Ask the caller to enter their 4-digit PIN using their phone keypad.",
                }

        # G27: Outage & TV Sub-Type Gate on #25 start_virtual_repair
        if tool_name == "start_virtual_repair":
            if str(state.get("outage_checked", "false")) != "true":
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Regional outage must be checked via check_regional_outage before starting virtual repair.",
                    "agent_action": "Call check_regional_outage first.",
                }
            lob_val = str(input.get("lob", "") or state.get("lob", "")).lower()
            tv_sub = str(input.get("tv_sub_type", "") or state.get("tv_sub_type", "null")).lower()
            if lob_val == "tv" and tv_sub in ("", "null", "none"):
                return {
                    "status": "error",
                    "error_code": "INVALID_INPUT",
                    "error": "INVALID_INPUT",
                    "message": "TV sub-type (streaming or satellite) must be disambiguated before starting TV virtual repair.",
                    "agent_action": "Ask the caller whether they have streaming TV or satellite TV.",
                }

        # G29: Coverage Gate on #36 fetch_plan_catalog for new service
        if tool_name == "fetch_plan_catalog":
            cust_type = str(input.get("customer_type", "") or state.get("customer_type", "Existing"))
            if cust_type.lower() == "new" and str(state.get("coverage_checked", "false")) != "true":
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Service coverage must be verified via check_service_coverage before presenting new service plans.",
                    "agent_action": "Call check_service_coverage first.",
                }

        # G31: Payment Preamble Gate on #19 process_payment and #20 configure_autopay
        if tool_name in ("process_payment", "configure_autopay"):
            if str(state.get("payment_preamble_played", "false")) != "true":
                state.update({"pending_verbatim_key": "payment_method_preamble"})
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "PCI payment_method_preamble must be delivered verbatim before processing payment or autopay.",
                    "agent_action": "Deliver the verbatim payment_method_preamble first, then proceed.",
                }

        # G32: Cancellation Disclosure Gate on #58 and #59
        if tool_name in ("submit_service_cancellation", "fetch_port_out_info"):
            if str(state.get("disclosure_played", "false")) != "true":
                disc_line = _render_verbatim(state, "contract_cancellation_fee_disclosure")
                state.update({"pending_verbatim_key": "contract_cancellation_fee_disclosure"})
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Contract cancellation fee disclosure must be read verbatim and confirmed before proceeding.",
                    "agent_action": f"Read contract_cancellation_fee_disclosure verbatim word-for-word and confirm with the caller: \"{disc_line}\"",
                }

        # G34: Zero-balance restore gate on #57 execute_suspend_restore
        if tool_name == "execute_suspend_restore":
            act = str(input.get("action", "")).lower()
            if act == "restore":
                try:
                    bal = float(str(state.get("balance_due", "0.00")) or "0.00")
                except Exception as exc:
                    print(f"Callback error: {exc}")
                    bal = 0.0
                if bal > 0.0:
                    state.update({
                        "pending_restore_after_payment": "true",
                        "route": "billing",
                    })
                    return {
                        "status": "error",
                        "error_code": "NOT_ELIGIBLE",
                        "error": "NOT_ELIGIBLE",
                        "message": f"Account has an outstanding balance of ${bal:.2f}. Balance must be $0.00 before restoration.",
                        "agent_action": "Route through telco_root_agent to billing_agent to clear the balance first.",
                    }

        # G35: Appointment cancel gate on #48 cancel_appointment
        if tool_name == "cancel_appointment":
            if str(state.get("appt_status", "")) == "en_route":
                return {
                    "status": "error",
                    "error_code": "NOT_ELIGIBLE",
                    "error": "NOT_ELIGIBLE",
                    "message": "Technician is already en_route; appointment cannot be cancelled.",
                    "agent_action": "Explain that the technician is en route and offer to add a technician note (#49).",
                }
            if str(state.get("same_day", "false")) == "true":
                conf_cnt = int(input.get("confirmation_count", 1) or 1)
                misc_cnt = int(str(state.get("misc_counter", "0")) or "0")
                if conf_cnt < 2 and misc_cnt < 1:
                    state.update({
                        "misc_counter": "1",
                        "pending_verbatim_key": "same_day_cancel_warning",
                    })
                    return {
                        "status": "error",
                        "error_code": "NOT_ELIGIBLE",
                        "error": "NOT_ELIGIBLE",
                        "message": "Same-day appointment cancellation requires two confirmations.",
                        "agent_action": "Deliver same_day_cancel_warning and ask the caller to confirm a second time.",
                    }

        # G42: Idempotency check for mutating tools
        if tool_name in MUTATING_TOOLS_CSV.split("|"):
            idem_key = str(input.get("idempotency_key", "")).strip()
            if idem_key:
                try:
                    cache = json.loads(str(state.get("idempotency_cache", "{}")))
                    if isinstance(cache, dict) and idem_key in cache:
                        return cache[idem_key]
                except Exception as exc:
                    print(f"Callback error: {exc}")
    except Exception as exc:
        print(f"Callback error: {exc}")
    return None
