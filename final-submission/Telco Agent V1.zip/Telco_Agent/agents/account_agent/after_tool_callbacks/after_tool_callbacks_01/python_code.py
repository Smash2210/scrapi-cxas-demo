"""Canonical shared callbacks for Telco_Voice_Agent (M1-M8).

Synchronized into all 8 agent callback directories by scripts/sync_callbacks.py.
Enforces PRD Section 6 preprocessing, Part C1/C2 verbatim copy, Part D grounding,
and Part E guardrails G1-G45 with strict string state typing (V101) and C001-C010 compliance.
"""

from typing import Any, Optional
import json
import re

AGENT_NAME = "account_agent"
AGENT_MODULE = "M7"

VERBATIM_C1: dict[str, dict[str, str]] = {
    "en-US": {
        "greeting_main": (
            "Welcome to Telco. I can help with billing, technical support, or managing your account. "
            "To get started, could you tell me the phone number or account number associated with your service?"
        ),
        "recording_notice": "This call may be recorded for quality and training purposes.",
        "id_verification_otp": (
            "For your security, I just sent a 6-digit code to that number — please read it back to me."
        ),
        "id_verification_pin": (
            "For your security, I'll need to verify your identity. Please enter the 4-digit PIN you set up."
        ),
        "live_agent_handoff": "I'll connect you to a representative who can help. Please hold.",
        "business_handoff": (
            "To get you the best support for your business account, I'll transfer you to an agent. "
            "You'll need to use your phone keypad instead of talking to the virtual assistant. "
            "Just a moment while I connect you."
        ),
        "payment_method_preamble": (
            "For your security and PCI compliance, please do not speak your card number aloud. "
            "Use your phone keypad when prompted to enter your payment details."
        ),
        "contract_cancellation_fee_disclosure": (
            "Please note that cancelling your service or porting out your number may result in an early "
            "termination fee if your line is under an active term contract, and any remaining device balance "
            "will become due on your final statement. Do you still wish to proceed?"
        ),
        "refund_confirmation_pattern": (
            "Your refund of ${amount} will appear on your next statement within {days} business days."
        ),
        "empathy_protocol": (
            "I'm very sorry to hear that you are facing challenges. "
            "I will ensure we handle your request with the utmost care."
        ),
        "outage_active": (
            "I see there's an active outage in your area. We're working on it. "
            "Would you like me to text you when it's restored?"
        ),
        "transfer_to_specialist": (
            "I'll connect you to a billing specialist now — they'll have everything we've already discussed."
        ),
    },
    "es-US": {
        "greeting_main": (
            "Bienvenido a Telco. Puedo ayudarle con facturación, soporte técnico o la administración de su cuenta. "
            "Para comenzar, ¿podría indicarme el número de teléfono o el número de cuenta asociado a su servicio?"
        ),
        "recording_notice": "Esta llamada puede ser grabada con fines de calidad y capacitación.",
        "id_verification_otp": (
            "Por su seguridad, acabo de enviar un código de 6 dígitos a ese número; por favor, léamelo."
        ),
        "id_verification_pin": (
            "Por su seguridad, necesito verificar su identidad. Por favor, ingrese el PIN de 4 dígitos que configuró."
        ),
        "live_agent_handoff": "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea.",
        "business_handoff": (
            "Para brindarle el mejor soporte para su cuenta de negocio, le transferiré con un agente. "
            "Deberá usar el teclado de su teléfono en lugar de hablar con el asistente virtual. "
            "Un momento mientras le comunico."
        ),
        "payment_method_preamble": (
            "Por su seguridad y cumplimiento de PCI, por favor no diga el número de su tarjeta en voz alta. "
            "Use el teclado de su teléfono cuando se le solicite ingresar sus datos de pago."
        ),
        "contract_cancellation_fee_disclosure": (
            "Tenga en cuenta que cancelar su servicio o transferir su número puede generar un cargo por "
            "cancelación anticipada si su línea tiene un contrato activo, y cualquier saldo pendiente del "
            "equipo vencerá en su factura final. ¿Desea continuar?"
        ),
        "refund_confirmation_pattern": (
            "Su reembolso de ${amount} aparecerá en su próximo estado de cuenta dentro de {days} días hábiles."
        ),
        "empathy_protocol": (
            "Lamento mucho que esté enfrentando estas dificultades. "
            "Me aseguraré de que su solicitud se atienda con el mayor cuidado."
        ),
        "outage_active": (
            "Veo que hay una interrupción activa del servicio en su zona. Estamos trabajando en ello. "
            "¿Desea que le envíe un mensaje de texto cuando se restablezca?"
        ),
        "transfer_to_specialist": (
            "Le comunicaré ahora con un especialista de facturación; tendrá toda la información que ya hemos conversado."
        ),
    },
}
VERBATIM_C1["primary"] = VERBATIM_C1["en-US"]
VERBATIM_C1["secondary"] = VERBATIM_C1["es-US"]

SYSTEM_LINES_C2: dict[str, dict[str, str]] = {
    "en-US": {
        "restricted_caller_deflection": (
            "We're unable to complete your call at this time. "
            "Please visit our website or a retail store for assistance. Goodbye."
        ),
        "regional_alert_banner": "Please note: {banner_text}",
        "otp_number_confirm": "I'll send a 6-digit code to the number ending in {last4}. Ready?",
        "noinput_reprompt_1": "I didn't catch that. Could you please repeat what you need help with?",
        "noinput_reprompt_2": (
            "I still didn't hear a response. Please tell me how I can help, "
            "or press 0 to speak with a representative."
        ),
        "nomatch_reprompt_1": (
            "To make sure I route you to the right place, is this about billing, "
            "technical support, sales, appointments, or your account?"
        ),
        "nomatch_reprompt_2": (
            "I want to make sure I understand. Could you briefly state which service you're calling about today?"
        ),
        "system_unavailable_line": (
            "I'm sorry, our system is temporarily unavailable. "
            "I'll connect you to a representative who can help. Please hold."
        ),
        "too_many_errors_line": (
            "I'm sorry, we've encountered too many errors processing that request. "
            "Please try calling back shortly. Goodbye."
        ),
        "malicious_closing_line": "I'm unable to continue this call. Goodbye.",
        "after_hours_notice": (
            "Our specialist team for that request is currently closed and will reopen at {next_open_iso}. "
            "Would you like me to schedule a callback for the next business day?"
        ),
        "password_reset_sent": (
            "I've sent a password reset link via text message to your phone. "
            "The link is valid for {valid_minutes} minutes."
        ),
        "same_day_cancel_warning": (
            "Because this appointment is scheduled for today, cancelling it cannot be undone once confirmed. "
            "Please confirm a second time if you are sure you want to cancel today's appointment."
        ),
        "closing_wrap": "Thank you for calling Telco. Have a great day! Goodbye.",
    },
    "es-US": {
        "restricted_caller_deflection": (
            "No podemos completar su llamada en este momento. "
            "Por favor visite nuestro sitio web o una tienda para recibir asistencia. Hasta luego."
        ),
        "regional_alert_banner": "Aviso importante: {banner_text}",
        "otp_number_confirm": "Enviaré un código de 6 dígitos al número que termina en {last4}. ¿Está listo?",
        "noinput_reprompt_1": "No logré escucharle. ¿Podría repetir en qué puedo ayudarle?",
        "noinput_reprompt_2": (
            "Sigo sin escuchar una respuesta. Por favor dígame cómo puedo ayudarle "
            "o presione 0 para hablar con un representante."
        ),
        "nomatch_reprompt_1": (
            "Para asegurarme de dirigirle al área correcta, ¿su consulta es sobre facturación, "
            "soporte técnico, ventas, citas o su cuenta?"
        ),
        "nomatch_reprompt_2": (
            "Quiero asegurarme de comprender bien. ¿Podría indicarme brevemente sobre qué servicio llama hoy?"
        ),
        "system_unavailable_line": (
            "Lo siento, nuestro sistema no está disponible temporalmente. "
            "Le comunicaré con un representante que pueda ayudarle. Por favor, espere en la línea."
        ),
        "too_many_errors_line": (
            "Lo siento, hemos encontrado demasiados errores al procesar su solicitud. "
            "Por favor intente llamar más tarde. Hasta luego."
        ),
        "malicious_closing_line": "No puedo continuar con esta llamada. Hasta luego.",
        "after_hours_notice": (
            "Nuestro equipo de especialistas para esa solicitud está cerrado actualmente y reabrirá a las {next_open_iso}. "
            "¿Desea que programe una devolución de llamada para el próximo día hábil?"
        ),
        "password_reset_sent": (
            "He enviado un enlace para restablecer su contraseña por mensaje de texto a su teléfono. "
            "El enlace es válido por {valid_minutes} minutos."
        ),
        "same_day_cancel_warning": (
            "Debido a que esta cita está programada para hoy, la cancelación no se puede deshacer una vez confirmada. "
            "Por favor confirme por segunda vez si está seguro de cancelar la cita de hoy."
        ),
        "closing_wrap": "Gracias por llamar a Telco. ¡Que tenga un excelente día! Hasta luego.",
    },
}
SYSTEM_LINES_C2["primary"] = SYSTEM_LINES_C2["en-US"]
SYSTEM_LINES_C2["secondary"] = SYSTEM_LINES_C2["es-US"]

VERBATIM_TEMPLATES = VERBATIM_C1
LEGAL_DISCLOSURES = SYSTEM_LINES_C2

DEFAULT_STATE_STRINGS: dict[str, str] = {
    "clid": "5550101001",
    "tfn": "8005550100",
    "cirn": "",
    "cirn_last4": "",
    "billing_account": "",
    "billing_account_last4": "",
    "customer_type": "Existing",
    "user_id": "",
    "zip": "",
    "line": "",
    "callback_number_last4": "",
    "has_backup_contact": "false",
    "auth_status": "",
    "identification_status": "",
    "step_up_auth_status": "",
    "auth_attempts": "0",
    "business_flag": "false",
    "route": "",
    "lob": "",
    "tv_sub_type": "null",
    "region": "Region-A",
    "active_module": "M1",
    "pending_restore_after_payment": "false",
    "language": "primary",
    "language_code": "en-US",
    "language_locked": "false",
    "utterance": "",
    "dtmf_digits": "",
    "local_noinput_counter": "0",
    "global_err_count": "0",
    "no_match_confirmation_count": "0",
    "misc_counter": "0",
    "mock_mode": "True",
    "test_profile": "standard",
    "mock_error_code": "",
    "now": "2026-10-29T14:00:00Z",
    "pending_verbatim_key": "",
    "recording_notice_played": "false",
    "payment_preamble_played": "false",
    "disclosure_played": "false",
    "outage_checked": "false",
    "coverage_checked": "false",
    "last_pmt_amt": "0.00",
    "amount": "",
    "balance_due": "0.00",
    "charge_id": "",
    "payment_token": "tok_visa_4242",
    "ban_type": "Consumer",
    "is_prepaid": "false",
    "loyalty_limit": "50",
    "vr_task_count": "0",
    "session_id": "",
    "ticket_state": "none",
    "device_id": "",
    "device_model": "",
    "appt_id": "",
    "item_list": "[]",
    "intent_type": "",
    "api_resp": "{}",
    "tool_response_values": "[]",
    "idempotency_cache": "{}",
    "sms_type": "Public",
    "sms_content": "",
    "day_val": "",
    "date_val": "",
    "month_val": "",
    "end_time": "",
    "flag_val": "",
    "banner_text": "",
    "next_open_iso": "",
    "valid_minutes": "30",
    "eta_business_days": "3",
    "escalation_reason": "",
    "queue_id": "general_support",
    "same_day": "false",
    "appt_status": "scheduled",
    "last_otp_input": "",
    "turn_1_greeted": "false",
}

AUTH_REQUIRED_TOOLS_CSV = (
    "fetch_recent_bills|evaluate_refund_eligibility|apply_bill_adjustment|create_dispute_ticket|"
    "process_payment|configure_autopay|fetch_payment_arrangement_options|create_payment_arrangement|"
    "fetch_deposit_info|start_virtual_repair|record_diagnostic_answer|lookup_support_ticket|"
    "create_support_ticket|fetch_sim_status|activate_sim|fetch_puk_code|"
    "check_device_unlock_eligibility|submit_device_unlock|fetch_account_services|place_new_order|"
    "check_warranty_status|process_warranty_claim|fetch_repair_options|initiate_number_transfer|"
    "fetch_active_appointments|fetch_technician_status|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|send_password_reset_sms|update_mfa_setting|"
    "update_profile_field|fetch_service_status|execute_suspend_restore|"
    "submit_service_cancellation|fetch_port_out_info"
)

MUTATING_TOOLS_CSV = (
    "schedule_next_business_day_callback|execute_live_agent_handover|execute_business_handover|"
    "apply_bill_adjustment|create_dispute_ticket|process_payment|configure_autopay|"
    "create_payment_arrangement|create_support_ticket|activate_sim|submit_device_unlock|"
    "place_new_order|process_warranty_claim|initiate_number_transfer|book_appointment|"
    "commit_appointment_reschedule|cancel_appointment|add_technician_note|"
    "register_availability_waitlist|update_mfa_setting|report_fraud|update_profile_field|"
    "execute_suspend_restore|submit_service_cancellation"
)

SYSTEM_ERROR_CODES_CSV = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
BUSINESS_ERROR_CODES_CSV = (
    "INSUFFICIENT_FUNDS|NOT_ELIGIBLE|ALREADY_APPLIED|QUEUE_CLOSED|REFUND_THRESHOLD_EXCEEDED|"
    "ERR_PAYMENT_DECLINED|ERR_CREDIT_LIMIT_EXCEEDED|ERR_NO_SLOTS_AVAILABLE|ERR_OUT_OF_STOCK|"
    "ERR_PORT_INELIGIBLE|ERR_OUTAGE_ACTIVE|ERR_DEVICE_UNREACHABLE|ERR_UNAUTHORIZED_ROLE"
)
VALIDATION_ERROR_CODES_CSV = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"


def _get_lang_key(state: Any) -> str:
    lang = str(state.get("language", "primary"))
    lang_code = str(state.get("language_code", "en-US"))
    if lang == "secondary" or lang_code == "es-US":
        return "es-US"
    return "en-US"


def _render_verbatim(state: Any, key: str) -> str:
    lang_key = _get_lang_key(state)
    c1_map = VERBATIM_C1.get(lang_key, VERBATIM_C1.get("en-US", {}))
    c2_map = SYSTEM_LINES_C2.get(lang_key, SYSTEM_LINES_C2.get("en-US", {}))
    template = c1_map.get(key) or c2_map.get(key) or ""
    if not template:
        return ""
    last4 = str(state.get("callback_number_last4", "") or state.get("cirn_last4", "") or "0000")
    amount_val = str(state.get("amount", "") or "0.00")
    days_val = str(state.get("eta_business_days", "") or "3")
    banner_val = str(state.get("banner_text", "") or "")
    next_open = str(state.get("next_open_iso", "") or "08:00 AM")
    valid_min = str(state.get("valid_minutes", "") or "30")
    rendered = template.replace("{last4}", last4)
    rendered = rendered.replace("{amount}", amount_val)
    rendered = rendered.replace("{days}", days_val)
    rendered = rendered.replace("{banner_text}", banner_val)
    rendered = rendered.replace("{next_open_iso}", next_open)
    rendered = rendered.replace("{valid_minutes}", valid_min)
    return rendered


def _extract_latest_user_text(callback_context: Any) -> str:
    try:
        user_content = getattr(callback_context, "user_content", None)
        if user_content and getattr(user_content, "parts", None):
            chunks = []
            for part in user_content.parts:
                txt = getattr(part, "text", None)
                if txt:
                    chunks.append(str(txt))
            if chunks:
                return " ".join(chunks).strip()
    except Exception as exc:
        print(f"Callback error: {exc}")
    return ""


def _record_tool_values(state: Any, payload: Any) -> None:
    try:
        existing_raw = str(state.get("tool_response_values", "[]"))
        try:
            values_list = json.loads(existing_raw)
            if not isinstance(values_list, list):
                values_list = []
        except Exception as exc:
            print(f"Callback error: {exc}")
            values_list = []

        def _walk(item: Any) -> None:
            if isinstance(item, dict):
                for k, v in item.items():
                    if k != "_pii_fields":
                        _walk(v)
            elif isinstance(item, list):
                for elem in item:
                    _walk(elem)
            elif item is not None:
                s_val = str(item).strip()
                if s_val and s_val not in values_list:
                    values_list.append(s_val)

        _walk(payload)
        state.update({"tool_response_values": json.dumps(values_list)})
    except Exception as exc:
        print(f"Callback error: {exc}")


def after_tool_callback(
    tool: Tool,
    input: dict[str, Any],
    callback_context: CallbackContext,
    tool_response: dict[str, Any],
) -> Optional[dict[str, Any]]:
    """Synchronize tool outputs into string state, classify errors (BR-TV-010), and queue verbatim lines."""
    try:
        state = callback_context.state
        tool_name = str(getattr(tool, "name", "") or "")
        if not isinstance(tool_response, dict):
            return None

        payload = (
            tool_response.get("result")
            if isinstance(tool_response.get("result"), dict)
            else tool_response
        )

        state.update({"api_resp": json.dumps(payload)})
        _record_tool_values(state, payload)

        # G42: Store in idempotency_cache if mutating tool succeeded
        if tool_name in MUTATING_TOOLS_CSV.split("|") and payload.get("status") == "success":
            idem_key = str(input.get("idempotency_key", "")).strip()
            if idem_key:
                try:
                    cache = json.loads(str(state.get("idempotency_cache", "{}")))
                    if not isinstance(cache, dict):
                        cache = {}
                    cache[idem_key] = payload
                    state.update({"idempotency_cache": json.dumps(cache)})
                except Exception as exc:
                    print(f"Callback error: {exc}")

        # Step 3: Tool-Error Tri-State Classification (BR-TV-010)
        err_code = str(payload.get("error_code", "") or payload.get("error", "")).strip()
        if err_code:
            if err_code in SYSTEM_ERROR_CODES_CSV.split("|"):
                state.update({
                    "pending_verbatim_key": "system_unavailable_line",
                    "escalation_reason": "system_unavailable",
                })
                return tool_response
            if err_code in VALIDATION_ERROR_CODES_CSV.split("|"):
                cur_err = int(str(state.get("global_err_count", "0")) or "0") + 1
                state.update({"global_err_count": str(cur_err)})
                if cur_err >= 3:
                    state.update({
                        "pending_verbatim_key": "too_many_errors_line",
                        "escalation_reason": "too_many_errors",
                    })
                return tool_response
            if err_code == "REFUND_THRESHOLD_EXCEEDED":
                state.update({
                    "pending_verbatim_key": "live_agent_handoff",
                    "escalation_reason": "refund_threshold_exceeded",
                })
                return tool_response

        # Synchronize flat string state keys from payload (G45)
        sync_keys = (
            "identification_status|user_id|cirn|cirn_last4|billing_account|billing_account_last4|"
            "customer_type|business_flag|is_prepaid|region|zip|line|callback_number_last4|"
            "has_backup_contact|ban_type|loyalty_limit|route|lob|intent_type|auth_status|"
            "step_up_auth_status|balance_due|last_pmt_amt|session_id|"
            "ticket_state|device_id|device_model|appt_id|appt_status|valid_minutes|eta_business_days|"
            "banner_text|next_open_iso"
        )
        for k in sync_keys.split("|"):
            if k in payload and payload.get(k) is not None:
                state.update({k: str(payload.get(k))})

        if "cirn" in payload and payload.get("cirn"):
            c_str = str(payload.get("cirn"))
            state.update({"cirn_last4": c_str[-4:] if len(c_str) >= 4 else c_str})
        if "billing_account" in payload and payload.get("billing_account"):
            b_str = str(payload.get("billing_account"))
            state.update({"billing_account_last4": b_str[-4:] if len(b_str) >= 4 else b_str})
        if "new_balance" in payload and payload.get("new_balance") is not None:
            state.update({"balance_due": str(payload.get("new_balance"))})

        # Tool-specific state & verbatim hooks
        if tool_name in ("execute_live_agent_handover", "execute_business_handover") and payload.get("status") == "success":
            end_reason = str(state.get("escalation_reason", "") or (
                "business_handoff" if tool_name == "execute_business_handover" else "user_requested_agent"
            ))
            line_key = (
                "business_handoff" if tool_name == "execute_business_handover"
                else "empathy_protocol" if end_reason == "fraud_escalation"
                else "live_agent_handoff"
            )
            payload["agent_action"] = (
                "The transfer succeeded. If you have not already said it aloud in this conversation, say exactly: "
                f"\"{_render_verbatim(state, line_key)}\" Say nothing else, then immediately call end_session with "
                f"reason='{end_reason}'."
            )
        # PRD M5/M6/M7: confirmations go out by SMS once the change is committed.
        if tool_name in (
            "book_appointment", "commit_appointment_reschedule", "cancel_appointment",
            "execute_suspend_restore", "place_new_order", "process_payment",
        ) and payload.get("status") == "success" and "agent_action" not in payload:
            payload["agent_action"] = (
                "Success. Tell the caller the result using the exact details above, then call send_sms to text them a "
                "confirmation and mention that the confirmation text is on its way."
            )
        if tool_name == "check_restricted_caller":
            if str(payload.get("blocked", "false")).lower() == "true":
                state.update({
                    "pending_verbatim_key": "restricted_caller_deflection",
                    "escalation_reason": "restricted_caller",
                })
        elif tool_name == "fetch_regional_service_alert":
            if str(payload.get("active", "false")).lower() == "true":
                state.update({
                    "banner_text": str(payload.get("banner_text", "")),
                    "pending_verbatim_key": "regional_alert_banner",
                })
        elif tool_name == "fetch_customer_profile":
            if str(payload.get("business_flag", "false")).lower() == "true":
                state.update({
                    "business_flag": "true",
                    "pending_verbatim_key": "business_handoff",
                    "escalation_reason": "business_handoff",
                })
        elif tool_name == "classify_malicious_utterance":
            if str(payload.get("hit", "false")).lower() == "true":
                state.update({
                    "pending_verbatim_key": "malicious_closing_line",
                    "escalation_reason": "malicious_input",
                })
        elif tool_name == "evaluate_routing_rules":
            route_val = str(payload.get("route", "")).strip()
            if route_val in ("", "disambiguate", "unknown", "none"):
                cur_nomatch = int(str(state.get("no_match_confirmation_count", "0")) or "0") + 1
                state.update({"no_match_confirmation_count": str(cur_nomatch)})
                if cur_nomatch < 3:
                    payload["agent_action"] = (
                        f"Disambiguation strike {cur_nomatch} of 3 (G6). Ask ONE short, targeted clarifying question "
                        "based on what the caller said (not a list of options), then call evaluate_routing_rules again "
                        "with the caller's clarified request."
                    )
                else:
                    handoff_line = _render_verbatim(state, "live_agent_handoff")
                    state.update({
                        "pending_verbatim_key": "live_agent_handoff",
                        "escalation_reason": "disambig_max_attempts",
                    })
                    payload["agent_action"] = (
                        f"Strike 3 disambiguation limit reached (G6). Deliver verbatim: \"{handoff_line}\" "
                        "and immediately call execute_live_agent_handover with reason='disambig_max_attempts'."
                    )
            else:
                state.update({"no_match_confirmation_count": "0"})
                req_auth = str(payload.get("requires_auth", "true")).lower()
                if req_auth == "true" and str(state.get("auth_status", "")) != "Pass":
                    payload["agent_action"] = (
                        f"Intent classified as route='{route_val}', lob='{payload.get('lob', '')}'. "
                        "Caller is not yet authenticated. Call fetch_customer_profile if not yet called, "
                        "then immediately transfer to auth_agent to verify the caller."
                    )
                else:
                    route_map = {
                        "billing": "billing_agent",
                        "tech": "secondary_language_agent" if _get_lang_key(state) == "es-US" else "tech_support_agent",
                        "sales": "sales_agent",
                        "appointments": "appointment_agent",
                        "account": "account_agent",
                    }
                    target_agent = route_map.get(route_val, "account_agent")
                    payload["agent_action"] = (
                        f"Intent classified as route='{route_val}', lob='{payload.get('lob', '')}'. "
                        f"Transfer immediately to {target_agent}."
                    )
        elif tool_name == "check_queue_hours":
            is_open = str(payload.get("open", "true")).lower()
            if is_open == "false":
                next_open = str(payload.get("next_open_iso", "08:00 AM"))
                state.update({
                    "next_open_iso": next_open,
                    "pending_verbatim_key": "after_hours_notice",
                })
                notice_line = _render_verbatim(state, "after_hours_notice")
                payload["agent_action"] = (
                    f"The {input.get('queue', 'specialist')} queue is currently CLOSED after hours. "
                    f"Deliver verbatim: \"{notice_line}\" and offer to schedule a next-business-day callback "
                    "using schedule_next_business_day_callback."
                )
            elif (
                AGENT_MODULE == "M7"
                or "retention" in str(input.get("queue", "")).lower()
                or "cancel" in str(input.get("queue", "")).lower()
            ) and str(state.get("disclosure_played", "false")) != "true":
                disc_line = _render_verbatim(state, "contract_cancellation_fee_disclosure")
                state.update({
                    "pending_verbatim_key": "contract_cancellation_fee_disclosure",
                })
                payload["agent_action"] = (
                    "Retention queue is open. Before calling submit_service_cancellation or fetch_port_out_info, "
                    f"you MUST deliver this exact disclosure verbatim word-for-word without any rephrasing and wait for the caller to confirm: \"{disc_line}\""
                )
        elif tool_name == "send_authentication_otp":
            if str(payload.get("sent", "false")).lower() == "true":
                state.update({"pending_verbatim_key": "id_verification_otp"})
        elif tool_name in ("validate_authentication_otp", "validate_authentication_pin"):
            if str(payload.get("auth_status", "")) != "Pass" or str(payload.get("step_up_auth_status", "")) == "Fail":
                attempts = int(str(state.get("auth_attempts", "0")) or "0") + 1
                state.update({"auth_attempts": str(attempts)})
                rem = str(payload.get("attempts_remaining", str(max(0, 3 - attempts))))
                if attempts >= 3 or rem == "0":
                    handoff_line = _render_verbatim(state, "live_agent_handoff")
                    state.update({
                        "pending_verbatim_key": "live_agent_handoff",
                        "escalation_reason": "auth_failure_handoff",
                    })
                    payload["agent_action"] = (
                        f"Maximum authentication attempts (3) reached (G9). Deliver verbatim: \"{handoff_line}\" "
                        "and immediately call execute_live_agent_handover with reason='auth_failure_handoff'."
                    )
                else:
                    payload["agent_action"] = (
                        f"Verification failed (attempt {attempts} of 3; {rem} attempts remaining). "
                        "Inform the caller that the code or PIN entered was incorrect and ask them to try again."
                    )
            else:
                state.update({"auth_attempts": "0"})
                payload["agent_action"] = (
                    f"Authentication succeeded (auth_status='Pass'). Return control to telco_root_agent immediately "
                    f"so it can route to the '{state.get('route', '')}' specialist."
                )
        elif tool_name == "evaluate_refund_eligibility":
            if str(payload.get("within_threshold", "true")).lower() == "false":
                state.update({
                    "pending_verbatim_key": "live_agent_handoff",
                    "escalation_reason": "refund_threshold_exceeded",
                })
        elif tool_name == "apply_bill_adjustment":
            if payload.get("status") == "success":
                state.update({
                    "amount": str(payload.get("amount", state.get("amount", "0.00"))),
                    "eta_business_days": str(payload.get("eta_business_days", "3")),
                    "pending_verbatim_key": "refund_confirmation_pattern",
                })
        elif tool_name == "check_regional_outage":
            state.update({"outage_checked": "true"})
            if str(payload.get("active", "false")).lower() == "true":
                state.update({
                    "pending_verbatim_key": "outage_active",
                })
        elif tool_name == "record_diagnostic_answer":
            steps_list = payload.get("steps", [])
            if isinstance(steps_list, list):
                state.update({"vr_task_count": str(len(steps_list))})
                if len(steps_list) > 2:
                    payload["agent_action"] = (
                        "More than 2 troubleshooting steps returned (G28). Offer to send these steps via SMS (#60 send_sms) before reading them."
                    )
        elif tool_name == "check_service_coverage":
            state.update({"coverage_checked": "true"})
        elif tool_name == "fetch_active_appointments":
            appts = payload.get("appointments", [])
            if isinstance(appts, list) and len(appts) == 1 and isinstance(appts[0], dict):
                state.update({
                    "appt_id": str(appts[0].get("appt_id", "")),
                    "appt_status": str(appts[0].get("status", "scheduled")),
                    "same_day": str(appts[0].get("same_day", "false")).lower(),
                })
        elif tool_name == "fetch_availability_slots":
            slots = payload.get("slots", [])
            if isinstance(slots, list) and len(slots) == 0:
                payload["agent_action"] = (
                    "No slots available in the requested window (G37). Offer to register the caller on the SMS waitlist via register_availability_waitlist (#50)."
                )
        elif tool_name == "send_password_reset_sms":
            if str(payload.get("sent", "false")).lower() == "true":
                state.update({
                    "valid_minutes": str(payload.get("valid_minutes", "30")),
                    "pending_verbatim_key": "password_reset_sent",
                })
    except Exception as exc:
        print(f"Callback error: {exc}")
    return tool_response
