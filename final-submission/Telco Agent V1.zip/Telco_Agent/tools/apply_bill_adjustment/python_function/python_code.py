"""Tool implementation for apply_bill_adjustment: Apply an approved credit or refund adjustment to the customer billing account."""

from typing import Any
import json


def apply_bill_adjustment(charge_id: str = "", amount: str = "", idempotency_key: str = "") -> dict[str, Any]:
    """Apply an approved credit or refund adjustment to the customer billing account.

    Args:
        charge_id: str, required — Line-item charge identifier formatted as 'CHG-XXX' (e.g., 'CHG-102').
        amount: str, required — Positive decimal dollar amount formatted as 'XX.XX' (e.g., '85.00'); falls back to session state balance_due or amount when omitted.
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, charge_id, amount, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, charge_id: str = "", amount: str = "", idempotency_key: str = "") -> dict[str, Any]:

    chg = _resolve_str(state, "charge_id", charge_id, "")
    raw_amt = _resolve_str(state, "amount", amount, "")
    amt_str = raw_amt.replace("$", "").strip()
    if not amt_str:
        return _make_error(
            "INVALID_INPUT",
            "Adjustment amount is required and was not found in call arguments or session state (G41).",
            "Verify the disputed charge amount via fetch_recent_bills and evaluate_refund_eligibility before applying an adjustment.",
        )
    try:
        adj_val = float(amt_str)
    except Exception:
        return _make_error(
            "INVALID_INPUT",
            f"Malformed adjustment amount '{amount}'. Expected a positive decimal dollar amount.",
            "Ask the caller to clarify the adjustment amount.",
        )
    if adj_val <= 0:
        return _make_error(
            "INVALID_INPUT",
            "Adjustment amount must be greater than zero.",
            "Ask the caller to confirm a positive adjustment amount.",
        )
    cur_bal_str = _resolve_str(state, "balance_due", "", "85.00")
    try:
        cur_bal = float(cur_bal_str) if cur_bal_str not in ("", "0", "0.0", "0.00") else 85.0
    except Exception:
        cur_bal = 85.0
    new_bal = max(0.0, cur_bal - adj_val)
    try:
        state.update({"balance_due": f"{new_bal:.2f}"})
    except Exception:
        pass
    return {
        "status": "success",
        "adjustment_id": "ADJ-5501",
        "charge_id": chg or "CHG-102",
        "amount": f"{adj_val:.2f}",
        "posts_to": "next statement",
        "eta_business_days": "3",
        "new_balance": f"{new_bal:.2f}",
    }
