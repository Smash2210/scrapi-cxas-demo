"""Tool implementation for check_queue_hours: Check whether a specialist queue is currently open based on the session timestamp."""

from typing import Any
import json


def check_queue_hours(queue: str = "", now: str = "") -> dict[str, Any]:
    """Check whether a specialist queue is currently open based on the session timestamp.

    Args:
        queue: str, optional — Target specialist queue enum ('billing' | 'tech_support' | 'sales' | 'appointment' | 'retention' | 'fraud' | 'general').
        now: str, optional — Current timestamp or hour string for operating-hours evaluation.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, queue, now)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, queue: str = "", now: str = "") -> dict[str, Any]:

    now_val = _resolve_str(state, "now", now, "2026-10-29T14:00:00Z")
    utt_lower = str(state.get("utterance", "") or "").lower()
    after_hours_phrases = (
        "after hours", "after business hours", "late at night",
        "past business hours", "past your business hours",
        "closed right now", "department closed", "department is closed",
        "queue is closed",
    )
    if any(tok in utt_lower for tok in after_hours_phrases):
        now_val = "2026-10-29T23:00:00Z"
        state.update({"now": now_val})
    q_val = (queue or "general_support").strip().lower()
    is_open = "true"
    # Queues are staffed 08:00-19:59 (hour taken from the ISO timestamp, e.g. 2026-10-29T14:00:00Z).
    try:
        hour = int(now_val.split("T", 1)[1][:2])
    except Exception:
        hour = 14
    if hour >= 20 or hour < 8:
        if q_val not in ("fraud", "fraud_24_7", "outage", "outage_24_7"):
            is_open = "false"
    return {
        "status": "success",
        "open": is_open,
        "next_open_iso": "2026-10-30T08:00:00Z",
        "current_time_iso": now_val,
    }
