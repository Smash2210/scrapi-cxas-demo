"""Tool implementation for process_warranty_claim: Submit a warranty replacement claim for an eligible manufacturer defect (rejects physical_damage per G39)."""

from typing import Any
import json


def process_warranty_claim(device_id: str = "", issue_type: str = "", description: str = "", idempotency_key: str = "") -> dict[str, Any]:
    """Submit a warranty replacement claim for an eligible manufacturer defect (rejects physical_damage per G39).

    Args:
        device_id: str, optional — Device identifier or IMEI (e.g., 'DEV-101'); automatically falls back to session state device_id.
        issue_type: str, required — Warranty issue classification enum ('hardware_defect' | 'battery' | 'physical_damage' | 'liquid_damage').
        description: str, required — Detailed text description of the device defect, warranty issue, or fraud report.
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, device_id, issue_type, description, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, device_id: str = "", issue_type: str = "", description: str = "", idempotency_key: str = "") -> dict[str, Any]:

    iss = str(issue_type or _resolve_str(state, "intent_type", "", "defect")).lower()
    if "physical" in iss or "cracked" in iss or "water" in iss or "liquid" in iss:
        return _make_error(
            "NOT_ELIGIBLE",
            "Physical or liquid damage is excluded from manufacturer warranty coverage (G39).",
            "Call fetch_repair_options (#41) to offer paid repair or insurance options.",
        )
    if profile == "out_of_warranty":
        return _make_error(
            "NOT_ELIGIBLE",
            "Device is out of warranty and not eligible for free warranty replacement (G40).",
            "Call fetch_repair_options (#41) to offer paid repair or upgrade options.",
        )
    return {
        "status": "success",
        "claim_id": "CLM-2910",
        "shipping_eta": "2026-11-01",
    }
