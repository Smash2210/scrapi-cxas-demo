"""Tool implementation for fetch_recent_bills: Retrieve recent billing statements, line-item charges, balance due, and due date for the billing account."""

from typing import Any
import json


def fetch_recent_bills(billing_account: str = "") -> dict[str, Any]:
    """Retrieve recent billing statements, line-item charges, balance due, and due date for the billing account.

    Args:
        billing_account: str, optional — Billing account number formatted as 'BA-XXXXXX'; automatically falls back to session state billing_account.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, billing_account)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, billing_account: str = "") -> dict[str, Any]:

    bal = "85.00" if profile in ("suspended_non_payment", "standard") else "120.00"
    if profile == "active":
        bal = "0.00"
    try:
        state.update({"balance_due": bal})
    except Exception:
        pass
    return {
        "status": "success",
        "bills": [
            {
                "statement_date": "2026-10-01",
                "total_amount": bal,
                "charges": [
                    {"charge_id": "CHG-101", "description": "Monthly Service Plan", "amount": "60.00"},
                    {"charge_id": "CHG-102", "description": "Data Overage / Administrative Fee", "amount": "25.00"},
                ],
            }
        ],
        "balance_due": bal,
        "due_date": "2026-11-15",
        "last_pmt_amt": "60.00",
    }
