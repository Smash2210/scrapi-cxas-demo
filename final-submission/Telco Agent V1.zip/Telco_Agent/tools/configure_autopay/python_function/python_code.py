"""Tool implementation for configure_autopay: Enroll or update recurring autopay using a tokenized payment method and monthly draft day (G31)."""

from typing import Any
import json


def configure_autopay(payment_token: str = "", draft_day: str = "", idempotency_key: str = "") -> dict[str, Any]:
    """Enroll or update recurring autopay using a tokenized payment method and monthly draft day (G31).

    Args:
        payment_token: str, optional — PCI-safe payment method token string (e.g., 'tok_visa_4242'); falls back to session state payment_token.
        draft_day: str, optional — Monthly billing draft day integer string between '1' and '28' (default '15').
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, payment_token, draft_day, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, payment_token: str = "", draft_day: str = "", idempotency_key: str = "") -> dict[str, Any]:

    day_raw = _resolve_str(state, "draft_day", draft_day, "")
    if not day_raw:
        return _make_error(
            "INVALID_INPUT",
            "Monthly draft_day (1-28) is required and was not found in call arguments or session state (G41).",
            "Ask the caller which monthly billing draft day (between 1 and 28) they prefer for autopay.",
        )
    day_clean = day_raw.lower().replace("th", "").replace("st", "").replace("nd", "").replace("rd", "").strip()
    try:
        day_int = int(day_clean)
    except Exception:
        return _make_error(
            "INVALID_INPUT",
            f"Malformed draft_day '{draft_day}'. Expected an integer day of the month between 1 and 28.",
            "Ask the caller to choose a numeric monthly draft day between 1 and 28.",
        )
    if day_int < 1 or day_int > 28:
        return _make_error(
            "INVALID_INPUT",
            f"draft_day '{day_int}' is out of range. Valid monthly draft days are 1 through 28.",
            "Ask the caller to choose a monthly draft day between 1 and 28.",
        )
    return {
        "status": "success",
        "autopay_status": "enabled",
        "effective_date": f"2026-11-{day_int:02d}",
        "draft_day": str(day_int),
    }
