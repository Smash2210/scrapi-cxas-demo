"""Tool implementation for execute_suspend_restore: Suspend or restore service on the customer account (requires balance_due == 0 for restore per G34)."""

from typing import Any
import json


def execute_suspend_restore(cirn: str = "", action: str = "", reason: str = "", idempotency_key: str = "") -> dict[str, Any]:
    """Suspend or restore service on the customer account (requires balance_due == 0 for restore per G34).

    Args:
        cirn: str, optional — Customer Internal Reference Number formatted as 'CIRN-XXXXXX'; automatically falls back to session state cirn.
        action: str, required — Target action enum (e.g., 'suspend' | 'restore' for execute_suspend_restore; 'enable' | 'disable' | 'update' for update_mfa_setting).
        reason: str, required — Structured reason code or description for handover, dispute, suspension/restoration, or service cancellation.
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, cirn, action, reason, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, cirn: str = "", action: str = "", reason: str = "", idempotency_key: str = "") -> dict[str, Any]:

    act = str(action or "restore").lower()
    if act == "restore":
        bal_str = _resolve_str(state, "balance_due", "", "0.00")
        try:
            bal_val = float(bal_str or "0.00")
        except Exception:
            bal_val = 0.0
        if bal_val > 0.0:
            return _make_error(
                "NOT_ELIGIBLE",
                f"Cannot restore service while balance_due is ${bal_val:.2f} (G34).",
                "Transfer through telco_root_agent to billing_agent to pay the balance first.",
            )
    new_st = "suspended" if "suspend" in act else "active"
    return {
        "status": "success",
        "new_state": new_st,
        "effective_iso": "2026-10-29T14:15:00Z",
    }
