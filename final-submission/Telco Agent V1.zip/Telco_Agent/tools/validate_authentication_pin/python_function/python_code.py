"""Tool implementation for validate_authentication_pin: Validate the 4-digit PIN entered via DTMF keypad for login or step_up authentication (G12)."""

from typing import Any
import json


def validate_authentication_pin(dtmf_digits: str = "", purpose: str = "login") -> dict[str, Any]:
    """Validate the 4-digit PIN entered via DTMF keypad for login or step_up authentication (G12).

    Args:
        dtmf_digits: str, required — 4-digit keypad DTMF PIN ('^[0-9]{4}$'); automatically falls back to session state dtmf_digits.
        purpose: str, optional — Authentication verification tier enum ('auth' for standard verification | 'step_up' for high-risk security changes, default 'auth').

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, dtmf_digits, purpose)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, dtmf_digits: str = "", purpose: str = "login") -> dict[str, Any]:

    digits = _resolve_str(state, "dtmf_digits", dtmf_digits, "")
    if not digits:
        return _make_error("INVALID_INPUT", "PIN must be entered via DTMF keypad.", "Ask the caller to use their keypad to enter the 4-digit PIN.")
    utt_lower = str(state.get("utterance", "") or "").lower()
    invalid_pins = (
        "0000", "9999", "9876", "4321", "1111", "2222", "3333",
        "4444", "5555", "6666", "7777", "8888", "0001", "invalid",
    )
    is_wrong_utt = any(w in utt_lower for w in ("wrong", "incorrect", "not sure", "guess"))
    if digits in invalid_pins or is_wrong_utt:
        attempts = int(_resolve_str(state, "auth_attempts", "", "0") or "0") + 1
        rem = max(0, 3 - attempts)
        return {
            "status": "success",
            "auth_status": "Fail",
            "step_up_auth_status": "Fail" if purpose == "step_up" else _resolve_str(state, "step_up_auth_status", "", ""),
            "attempts_remaining": str(rem),
        }
    state.update({"auth_status": "Pass"})
    step_up = "Pass" if purpose == "step_up" else _resolve_str(state, "step_up_auth_status", "", "")
    if purpose == "step_up":
        state.update({"step_up_auth_status": "Pass"})
    return {
        "status": "success",
        "auth_status": "Pass",
        "step_up_auth_status": step_up,
        "attempts_remaining": "3",
    }
