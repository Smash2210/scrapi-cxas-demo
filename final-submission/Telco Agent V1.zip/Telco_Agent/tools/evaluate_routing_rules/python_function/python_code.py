"""Tool implementation for evaluate_routing_rules: Classify caller utterance and extracted entities into target capability module and auth requirement."""

from typing import Any
import json


def evaluate_routing_rules(utterance: str = "", entities: str = "") -> dict[str, Any]:
    """Classify caller utterance and extracted entities into target capability module and auth requirement.

    Args:
        utterance: str, required — Raw caller turn utterance text to evaluate.
        entities: str, optional — JSON-encoded or comma-separated extracted intent entities from the caller utterance.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, utterance, entities)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, utterance: str = "", entities: str = "") -> dict[str, Any]:

    utt = _resolve_str(state, "utterance", utterance, "").lower()
    ent = str(entities or "").lower()
    combined = f"{utt} {ent}"

    lob_val = _resolve_str(state, "lob", "", "mobility")
    if any(k in combined for k in ("internet", "fiber", "broadband", "wifi", "wi-fi", "modem", "router")):
        lob_val = "internet"
    elif any(k in combined for k in ("tv", "television", "cable", "satellite", "channel")):
        lob_val = "tv"
    elif any(k in combined for k in ("mobile", "mobility", "cell", "phone", "sim", "esim", "puk", "port")):
        lob_val = "mobility"

    route_val = "disambiguate"
    intent_val = "unknown"
    req_auth = "true"

    if any(
        k in utt
        for k in (
            "appointment",
            "reschedule",
            "technician",
            "tech visit",
            "service visit",
            "time slot",
            "waitlist",
            "en route",
            "on their way",
            "on his way",
            "book a",
            "cita",
            "técnico",
            "tecnico",
        )
    ):
        route_val = "appointments"
        intent_val = "appointment_mgmt"
    elif any(
        k in utt
        for k in (
            "cancel",
            "port out",
            "port-out",
            "transfer pin",
            "leave telco",
            "close my account",
            "disconnect",
            "password",
            "mfa",
            "two-factor",
            "two factor",
            "2fa",
            "autenticación",
            "autenticacion",
            "factores",
            "contraseña",
            "contrasena",
            "fraud",
            "unauthorized",
            "identity theft",
            "stolen",
            "lost phone",
            "lost my phone",
            "hacked",
            "compromised",
            "locked out of my account",
            "account is locked",
            "account locked",
            "fake account",
            "suspend",
            "restore",
            "reconnect",
            "reactivate",
            "profile",
            "email address",
            "mailing address",
            "register",
            "online access",
        )
    ):
        route_val = "account"
        intent_val = "account_mgmt"
        if any(
            f in utt
            for f in ("fraud", "unauthorized", "identity theft", "hacked", "fake account", "register")
        ):
            req_auth = "false"
    elif any(
        k in utt
        for k in (
            "bill",
            "charge",
            "dispute",
            "payment",
            "pay ",
            "autopay",
            "auto-pay",
            "auto pay",
            "refund",
            "credit",
            "balance",
            "statement",
            "overcharged",
            "installment",
            "arrangement",
            "deposit",
            "factura",
            "cobro",
            "pago",
            "fee",
        )
    ):
        route_val = "billing"
        intent_val = "billing_inquiry"
    elif any(
        k in utt
        for k in (
            "upgrade",
            "downgrade",
            "plan",
            "coverage",
            "available in",
            "warranty",
            "broken screen",
            "cracked",
            "replacement",
            "add tv",
            "add a",
            "add-on",
            "addon",
            "streaming",
            "transfer my number",
            "transfer my current",
            "transfer my phone number",
            "move my number",
            "from my old carrier",
            "from another carrier",
            "switch carriers",
            "switch to telco",
            "porting",
            "transfer a number",
            "keep my number",
            "port in",
            "port-in",
            "bring my number",
            "new service",
            "buy",
            "order",
        )
    ):
        route_val = "sales"
        intent_val = "sales_order"
        req_auth = (
            "false"
            if ("coverage" in utt or "available in" in utt or "new service" in utt)
            and "existing" not in utt
            else "true"
        )
    elif any(
        k in utt
        for k in (
            "outage",
            "signal",
            "no service",
            "sim",
            "esim",
            "puk",
            "unlock",
            "locked",
            "lock screen",
            "screen lock",
            "bloqueado",
            "slow",
            "dropping",
            "dropped",
            "not working",
            "down",
            "no internet",
            "internet issue",
            "tv issue",
            "pixelating",
            "buffering",
            "black screen",
            "no picture",
            "troubleshoot",
            "repair",
            "ticket",
            "diagnostic",
            "modem",
            "router",
            "reboot",
            "tech",
            "internet",
            "tv",
            "soporte",
            "señal",
            "senal",
            "lento",
        )
    ):
        route_val = "tech"
        intent_val = "tech_support"
    elif "bill" in ent or "payment" in ent:
        route_val = "billing"
        intent_val = "billing_inquiry"
    elif "account" in ent:
        route_val = "account"
        intent_val = "account_mgmt"
    elif "appointment" in ent:
        route_val = "appointments"
        intent_val = "appointment_mgmt"
    elif any(k in ent for k in ("port", "transfer_in", "number_transfer", "plan", "upgrade", "warranty", "order", "add-on", "addon")):
        route_val = "sales"
        intent_val = "sales_order"
    elif any(k in ent for k in ("password", "mfa", "two-factor", "2fa", "fraud", "suspend", "restore", "cancel", "profile")):
        route_val = "account"
        intent_val = "account_mgmt"
    elif any(k in ent for k in ("appointment", "technician", "ticket", "visit")):
        route_val = "appointments"
        intent_val = "appointment_mgmt"
    elif any(k in ent for k in ("outage", "sim", "puk", "unlock", "lock", "internet", "signal", "repair")):
        route_val = "tech"
        intent_val = "tech_support"
    elif "sales" in ent:
        route_val = "sales"
        intent_val = "sales_order"
    elif "tech" in ent:
        route_val = "tech"
        intent_val = "tech_support"

    try:
        state.update({"route": route_val, "lob": lob_val, "intent_type": intent_val})
    except Exception:
        pass

    return {
        "status": "success",
        "route": route_val,
        "confidence": "0.95",
        "requires_auth": req_auth,
        "lob": lob_val,
        "intent_type": intent_val,
    }
