"""Tool implementation for fetch_customer_profile: Resolve caller identity and account metadata by CLID, phone number, or billing account number."""

from typing import Any
import json


def fetch_customer_profile(clid: str = "", phone: str = "", account_number: str = "") -> dict[str, Any]:
    """Resolve caller identity and account metadata by CLID, phone number, or billing account number.

    Args:
        clid: str, optional — Calling Line Identification 10-digit phone number (digits only); automatically falls back to session state clid.
        phone: str, optional — Alternate 10-digit lookup phone number when CLID is unverified.
        account_number: str, optional — Customer billing account identifier (e.g., 'BA-900123'); falls back to session state billing_account.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, clid, phone, account_number)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, clid: str = "", phone: str = "", account_number: str = "") -> dict[str, Any]:

    clid_val = _resolve_str(state, "clid", clid, "5550101001")
    acct_val = _resolve_str(state, "billing_account", account_number, "8849201948")
    cirn_val = "7738195501"
    is_biz = "true" if profile == "business" else "false"
    is_prep = "true" if profile == "prepaid" else "false"
    cust_type = "New" if profile == "no_slots" and not clid_val else "Existing"
    return {
        "status": "success",
        "identification_status": "Pass",
        "user_id": "USR-10029",
        "cirn": cirn_val,
        "cirn_last4": cirn_val[-4:],
        "billing_account": acct_val,
        "billing_account_last4": acct_val[-4:],
        "customer_type": cust_type,
        "business_flag": is_biz,
        "is_prepaid": is_prep,
        "region": "Region-A",
        "zip": "10001",
        "line": phone or clid_val or "5550101001",
        "callback_number_last4": (phone or clid_val or "5550101001")[-4:],
        "has_backup_contact": "true",
        "ban_type": "Business" if is_biz == "true" else "Consumer",
        "loyalty_limit": "50",
        "_pii_fields": ["cirn", "billing_account", "line"],
    }
