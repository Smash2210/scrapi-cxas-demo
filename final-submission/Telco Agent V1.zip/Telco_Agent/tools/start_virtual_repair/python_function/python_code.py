"""Tool implementation for start_virtual_repair: Initialize an interactive virtual repair diagnostic session after regional outage check (G27)."""

from typing import Any
import json


def start_virtual_repair(cirn: str = "", lob: str = "", symptom: str = "", tv_sub_type: str = "") -> dict[str, Any]:
    """Initialize an interactive virtual repair diagnostic session after regional outage check (G27).

    Args:
        cirn: str, optional — Customer Internal Reference Number formatted as 'CIRN-XXXXXX'; automatically falls back to session state cirn.
        lob: str, optional — Line of business enum ('mobility' | 'internet' | 'tv'); automatically falls back to session state lob.
        symptom: str, optional — Reported technical issue symptom code or summary (e.g., 'no_connection', 'slow_speed', 'no_signal').
        tv_sub_type: str, optional — Television service delivery enum ('streaming' | 'satellite') required when lob is 'tv'; falls back to session state tv_sub_type.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, cirn, lob, symptom, tv_sub_type)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, cirn: str = "", lob: str = "", symptom: str = "", tv_sub_type: str = "") -> dict[str, Any]:

    lob_val = _resolve_str(state, "lob", lob, "internet").lower()
    q_text = "Are the status lights on your modem or receiver blinking red or solid green?"
    if lob_val == "mobility":
        q_text = "Have you restarted your mobile device and toggled airplane mode off?"
    return {
        "status": "success",
        "vr_session_id": "VRS-2001",
        "session_id": "VRS-2001",
        "first_diagnostic_question": q_text,
        "question_id": "Q1",
    }
