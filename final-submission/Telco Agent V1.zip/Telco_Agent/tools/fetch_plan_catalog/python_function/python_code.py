"""Tool implementation for fetch_plan_catalog: Retrieve up to 3 eligible service plans for the requested line of business and customer type (G15, G29)."""

from typing import Any
import json


def fetch_plan_catalog(lob: str = "", customer_type: str = "", plan_filter: str = "", max_results: int = 3) -> dict[str, Any]:
    """Retrieve up to 3 eligible service plans for the requested line of business and customer type (G15, G29).

    Args:
        lob: str, optional — Line of business enum ('mobility' | 'internet' | 'tv'); automatically falls back to session state lob.
        customer_type: str, optional — Customer segment enum ('consumer' | 'business', default 'consumer').
        plan_filter: str, optional — Optional keyword filter for plan catalog search (e.g., 'unlimited', 'fiber', 'family').
        max_results: str, optional — Maximum catalog items to return (capped at '3' per G15).

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, lob, customer_type, plan_filter, max_results)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, lob: str = "", customer_type: str = "", plan_filter: str = "", max_results: int = 3) -> dict[str, Any]:

    cap = min(3, max(1, int(max_results or 3)))
    plans = [
        {"plan_id": "PLN-ESS", "name": "Telco Essential", "price": "45.00", "key_features": "Unlimited talk, text, and 5G data"},
        {"plan_id": "PLN-PLUS", "name": "Telco Plus", "price": "65.00", "key_features": "Priority 5G data and 25GB hotspot"},
        {"plan_id": "PLN-ULT", "name": "Telco Ultimate", "price": "80.00", "key_features": "Unlimited premium data, 50GB hotspot, and streaming perk"},
    ]
    return {
        "status": "success",
        "plans": plans[:cap],
    }
