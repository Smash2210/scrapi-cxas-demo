"""Tool implementation for create_payment_arrangement: Commit a selected payment arrangement option on the customer billing account."""

from typing import Any
import json


def create_payment_arrangement(option_id: str = "", idempotency_key: str = "") -> dict[str, Any]:
    """Commit a selected payment arrangement option on the customer billing account.

    Args:
        option_id: str, required — Selected payment arrangement option identifier ('ARR-2PT' | 'ARR-EXT') from fetch_payment_arrangement_options.
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, option_id, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, option_id: str = "", idempotency_key: str = "") -> dict[str, Any]:

    opt = _resolve_str(state, "option_id", option_id, "").upper()
    if not opt:
        return _make_error(
            "INVALID_INPUT",
            "Payment arrangement option_id is required and was not found in call arguments or session state (G41).",
            "Call fetch_payment_arrangement_options first and ask the caller to select an arrangement option ('ARR-2PT' or 'ARR-EXT').",
        )
    valid_schedules = {
        "ARR-2PT": "2026-11-10 and 2026-11-24",
        "ARR-EXT": "2026-11-20",
    }
    if opt not in valid_schedules:
        return _make_error(
            "INVALID_INPUT",
            f"Unrecognized payment arrangement option_id '{option_id}'. Valid options are 'ARR-2PT' or 'ARR-EXT'.",
            "Ask the caller to choose one of the presented arrangement options ('ARR-2PT' or 'ARR-EXT').",
        )
    return {
        "status": "success",
        "arrangement_id": "ARG-6102",
        "option_id": opt,
        "schedule": valid_schedules[opt],
    }
