"""Tool implementation for fetch_active_appointments: Retrieve active technician appointments associated with the customer CIRN (G35, G36)."""

from typing import Any
import json


def fetch_active_appointments(cirn: str = "") -> dict[str, Any]:
    """Retrieve active technician appointments associated with the customer CIRN (G35, G36).

    Args:
        cirn: str, optional — Customer Internal Reference Number formatted as 'CIRN-XXXXXX'; automatically falls back to session state cirn.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, cirn)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, cirn: str = "") -> dict[str, Any]:

    if profile == "multiple_appointments":
        return {
            "status": "success",
            "appointments": [
                {
                    "appt_id": "APT-101",
                    "service_type": "internet_install",
                    "address": "123 Main St",
                    "date": "2026-11-03",
                    "window": "08:00 AM - 12:00 PM",
                    "status": "scheduled",
                    "same_day": "false",
                },
                {
                    "appt_id": "APT-102",
                    "service_type": "tv_repair",
                    "address": "456 Oak Ave",
                    "date": "2026-11-05",
                    "window": "01:00 PM - 05:00 PM",
                    "status": "scheduled",
                    "same_day": "false",
                },
            ],
        }
    appt_st = "en_route" if profile == "tech_en_route" else "scheduled"
    is_same = "true" if profile in ("same_day_appointment", "tech_en_route") else "false"
    appt_dt = "2026-10-29" if is_same == "true" else "2026-11-03"
    return {
        "status": "success",
        "appointments": [
            {
                "appt_id": "APT-101",
                "service_type": "internet_repair",
                "address": "123 Main St",
                "date": appt_dt,
                "window": "01:00 PM - 05:00 PM",
                "status": appt_st,
                "same_day": is_same,
            }
        ],
    }
