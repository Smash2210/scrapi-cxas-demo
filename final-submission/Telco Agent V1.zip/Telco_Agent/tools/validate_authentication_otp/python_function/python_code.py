"""Tool implementation for validate_authentication_otp: Validate the 6-digit OTP code provided by the caller for login or step_up authentication."""

from typing import Any
import json


def validate_authentication_otp(code: str = "", purpose: str = "login") -> dict[str, Any]:
    """Validate the 6-digit OTP code provided by the caller for login or step_up authentication.

    Args:
        code: str, required — 6-digit numeric SMS One-Time Passcode ('^[0-9]{6}$') spoken by the caller.
        purpose: str, optional — Authentication verification tier enum ('auth' for standard verification | 'step_up' for high-risk security changes, default 'auth').

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, code, purpose)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, code: str = "", purpose: str = "login") -> dict[str, Any]:

    clean_code = str(code or _resolve_str(state, "dtmf_digits", "", "")).strip()
    utt_lower = str(state.get("utterance", "") or "").lower()
    invalid_codes = (
        "000000", "999999", "987654", "111111", "222222", "333333",
        "444444", "555555", "666666", "777777", "888888", "000001",
        "123123", "invalid",
    )
    is_wrong_utt = any(w in utt_lower for w in ("wrong", "incorrect", "not sure", "guess"))
    if not clean_code or clean_code in invalid_codes or is_wrong_utt:
        attempts = int(_resolve_str(state, "auth_attempts", "", "0") or "0") + 1
        rem = max(0, 3 - attempts)
        return {
            "status": "success",
            "auth_status": "Fail",
            "step_up_auth_status": "Fail" if purpose == "step_up" else _resolve_str(state, "step_up_auth_status", "", ""),
            "attempts_remaining": str(rem),
        }
    state.update({"last_otp_input": clean_code, "auth_status": "Pass"})
    step_up = "Pass" if purpose == "step_up" else _resolve_str(state, "step_up_auth_status", "", "")
    if purpose == "step_up":
        state.update({"step_up_auth_status": "Pass"})
    return {
        "status": "success",
        "auth_status": "Pass",
        "step_up_auth_status": step_up,
        "attempts_remaining": "3",
    }
