"""Tool implementation for cancel_appointment: Cancel a scheduled appointment (blocks en_route and enforces 2 confirmations for same-day per G35)."""

from typing import Any
import json


def cancel_appointment(appt_id: str = "", confirmation_count: int = 1, idempotency_key: str = "") -> dict[str, Any]:
    """Cancel a scheduled appointment (blocks en_route and enforces 2 confirmations for same-day per G35).

    Args:
        appt_id: str, required — Appointment identifier formatted as 'APT-XXXX' (e.g., 'APT-301'); falls back to session state appt_id.
        confirmation_count: str, optional — Number of caller cancellation confirmations recorded ('1' or '2' for same-day appointments); falls back to session state cancel_confirmation_count.
        idempotency_key: str, optional — Unique idempotency token string to prevent duplicate mutating operations within the session.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    idem_key = str(idempotency_key or "").strip()
    if idem_key:
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if isinstance(cache, dict) and idem_key in cache:
                return cache[idem_key]
        except Exception:
            pass

    result = _execute(state, profile, appt_id, confirmation_count, idempotency_key)

    if idem_key and isinstance(result, dict) and result.get("status") == "success":
        try:
            cache = json.loads(str(state.get("idempotency_cache", "{}")))
            if not isinstance(cache, dict):
                cache = {}
            cache[idem_key] = result
            state.update({"idempotency_cache": json.dumps(cache)})
        except Exception:
            pass

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, appt_id: str = "", confirmation_count: int = 1, idempotency_key: str = "") -> dict[str, Any]:

    if profile == "tech_en_route" or _resolve_str(state, "appt_status", "", "") == "en_route":
        return _make_error(
            "NOT_ELIGIBLE",
            "Appointment cannot be cancelled because the technician is already en route (G35).",
            "Offer to add a technician note via add_technician_note (#49).",
        )
    if (profile == "same_day_appointment" or _resolve_str(state, "same_day", "", "false") == "true") and int(confirmation_count or 1) < 2:
        return _make_error(
            "NOT_ELIGIBLE",
            "Same-day appointment cancellation requires a second confirmation from the caller (G35).",
            "Read same_day_cancel_warning and confirm a second time before calling cancel_appointment with confirmation_count=2.",
        )
    return {
        "status": "success",
        "cancelled": "true",
    }
