"""Tool implementation for evaluate_refund_eligibility: Check whether a disputed charge is eligible for automatic bill adjustment within policy threshold (G30)."""

from typing import Any
import json


def evaluate_refund_eligibility(charge_id: str = "", amount: str = "") -> dict[str, Any]:
    """Check whether a disputed charge is eligible for automatic bill adjustment within policy threshold (G30).

    Args:
        charge_id: str, required — Line-item charge identifier formatted as 'CHG-XXX' (e.g., 'CHG-102').
        amount: str, required — Positive decimal dollar amount formatted as 'XX.XX' (e.g., '85.00'); falls back to session state balance_due or amount when omitted.

    Returns:
        Dictionary with status ('success' or 'error') and tool-specific output fields.
    """
    state = _get_state()
    injected = _check_fault_injection(state)
    if injected is not None:
        return injected
    profile = str(state.get("test_profile", "standard") or "standard").strip()

    result = _execute(state, profile, charge_id, amount)

    return result


def _get_state() -> dict[str, Any]:
    """Retrieve session state dictionary from injected context if available."""
    try:
        ctx = globals().get("context") or globals().get("callback_context")
        if ctx is not None and hasattr(ctx, "state"):
            return ctx.state
    except Exception:
        pass
    return {}


def _resolve_str(state: Any, key: str, passed: str, fallback: str) -> str:
    """Resolve parameter from passed argument first, then session state, then fallback."""
    if passed is not None and str(passed).strip() != "":
        return str(passed).strip()
    try:
        val = state.get(key)
        if val is not None and str(val).strip() not in ("", "null"):
            return str(val).strip()
    except Exception:
        pass
    return fallback


def _make_error(code: str, message: str, agent_action: str) -> dict[str, Any]:
    """Build standard tri-state error response dictionary (T001, BR-TV-010)."""
    return {
        "status": "error",
        "error_code": code,
        "error": code,
        "message": message,
        "agent_action": agent_action,
    }


def _check_fault_injection(state: Any) -> dict[str, Any] | None:
    """Return fault-injected error dictionary when mock_error_code is active (G43)."""
    err = str(state.get("mock_error_code", "") or "").strip()
    if not err:
        return None
    system_codes = "SYSTEM_DOWN|INTERNAL_ERROR|AUTH_SERVICE_UNAVAILABLE|ERR_BACKEND_TIMEOUT"
    if err in system_codes.split("|"):
        return _make_error(
            err,
            f"Backend service encountered system error: {err}.",
            "Apologize for the system issue and immediately escalate via execute_live_agent_handover with reason='system_unavailable'.",
        )
    if err == "REFUND_THRESHOLD_EXCEEDED":
        return _make_error(
            err,
            "Requested refund exceeds automatic threshold.",
            "Escalate to a specialist via execute_live_agent_handover with reason='refund_threshold_exceeded'.",
        )
    validation_codes = "INVALID_INPUT|MALFORMED_REQUEST|ERR_INVALID_PIN|ERR_EXPIRED_OTP"
    if err in validation_codes.split("|"):
        return _make_error(
            err,
            f"Input validation failed with code {err}.",
            "Ask the caller to clarify or re-enter the information.",
        )
    return _make_error(
        err,
        f"Business rule prevented completion ({err}).",
        "Apologize and offer the caller an alternative self-service option or specialist assistance.",
    )


def _execute(state: Any, profile: str, charge_id: str = "", amount: str = "") -> dict[str, Any]:

    chg = _resolve_str(state, "charge_id", charge_id, "CHG-102")
    amt_str = _resolve_str(state, "amount", amount, "25.00").replace("$", "").strip()
    try:
        amt_val = float(amt_str or "25.00")
    except Exception:
        return _make_error(
            "INVALID_INPUT",
            f"Malformed refund amount '{amount}'.",
            "Ask the caller to clarify the disputed charge amount.",
        )
    if amt_val <= 0:
        return _make_error(
            "INVALID_INPUT",
            "Refund amount must be greater than zero.",
            "Ask the caller to clarify the disputed charge amount.",
        )
    try:
        state.update({"amount": f"{amt_val:.2f}", "charge_id": chg})
    except Exception:
        pass
    limit_val = float(_resolve_str(state, "loyalty_limit", "", "50") or "50")
    within = "true" if amt_val <= limit_val else "false"
    if within == "false":
        return {
            "status": "error",
            "error_code": "REFUND_THRESHOLD_EXCEEDED",
            "error": "REFUND_THRESHOLD_EXCEEDED",
            "auto_eligible": "false",
            "within_threshold": "false",
            "max_auto_amount": f"{limit_val:.2f}",
            "message": "Requested adjustment exceeds the automated policy threshold.",
            "agent_action": "Escalate to a billing specialist via execute_live_agent_handover.",
        }
    return {
        "status": "success",
        "auto_eligible": "true",
        "within_threshold": "true",
        "max_auto_amount": f"{limit_val:.2f}",
    }
